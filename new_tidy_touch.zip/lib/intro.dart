import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'cleaning.dart';
import 'create_account_page_cutomer.dart';
import 'location_service.dart';

class StartPage extends StatefulWidget {
  const StartPage({Key? key}) : super(key: key);

  @override
  _StartPageState createState() => _StartPageState();
}

class _StartPageState extends State<StartPage> {
  int selectedService = 0;

  @override
  void initState() {
    super.initState();
    // Randomly select from service list every 2 seconds
    Timer.periodic(Duration(seconds: 2), (timer) {
      setState(() {
        selectedService =
            Random().nextInt(2); // Assuming only 2 services for simplicity
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 100),
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(80),
                    topRight: Radius.circular(80),
                  ),
                ),
                child: Column(
                  children: [
                    Center(
                      child: Image.asset(
                        'assets/new_clening.png.jpg',
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(height: 20), // Add some spacing after the image
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      child: Center(
                        child: Text(
                          'Easy, Reliable Way \nto Take Care \nof Your House...',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey.shade900,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 60),
                      child: Center(
                        child: Text(
                          'We provide you with the best people to help take care of your house.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(50.0),
                      child: _buildElevatedButton(
                        onPressed: _showLocationAccessDialog,
                        text: 'Get Started',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showLocationAccessDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Location Access',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          content: Text(
            'How would you like to manage your location access?',
            textAlign: TextAlign.center, // Aligns the text to the center
          ),
          actions: <Widget>[
            TextButton(
              child: Center(
                child: Text(
                  'Always On',
                  style:
                      TextStyle(color: Colors.blue), // Set text color to blue
                ),
              ),
              onPressed: () {
                // Handle "Always On" option
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CleaningPage(
                            isServiceProvider: false,
                            onToggleRole: () {},
                          )),
                );
              },
            ),
            TextButton(
              child: Center(
                child: Text(
                  'Only When Using the App',
                  style:
                      TextStyle(color: Colors.blue), // Set text color to blue
                ),
              ),
              onPressed: () {
                // Handle "Only When Using the App" option
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CleaningPage(
                            isServiceProvider: false,
                            onToggleRole: () {},
                          )),
                );
              },
            ),
            TextButton(
              child: Center(
                child: Text(
                  'Off',
                  style:
                      TextStyle(color: Colors.blue), // Set text color to blue
                ),
              ),
              onPressed: () {
                // Handle "Off" option
                LocationService locationService = LocationService();
                locationService.handleLocationAccess('Off');
                showLocationOffNotification(); // Show the toast notification
                // Do not navigate away from the dialog
              },
            ),
          ],
        );
      },
    );
  }

  void showLocationOffNotification() {
    Fluttertoast.showToast(
        msg: "Please press another choice for accessing your current location.",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 3,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);
  }

  Widget _buildElevatedButton({
    required VoidCallback onPressed,
    required String text,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(
            color: Color(0xFFDBE2EF),
            fontSize: 25,
            fontWeight: FontWeight.w500),
      ),
      style: ElevatedButton.styleFrom(
        fixedSize: Size(250, 60),
        padding: EdgeInsets.symmetric(vertical: 15),
        backgroundColor: Color(0xFF112D4E),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
      ),
    );
  }
}
