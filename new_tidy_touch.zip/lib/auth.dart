/*import 'package:firebase_auth/firebase_auth.dart';

class FirebaseAuthService {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  Future<User?> signInWithPhoneNumber(String phoneNumber, String password) async {
    try {
      // Start the phone number sign-in process
      await _firebaseAuth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Auto-sign in if possible
          UserCredential userCredential = await _firebaseAuth.signInWithCredential(credential);
          return userCredential.user;
        },
        verificationFailed: (FirebaseAuthException e) {
          print("Verification failed: ${e.message}");
          return null;
        },
        codeSent: (String verificationId, int? resendToken) async {
          // Prompt the user to enter the SMS code
          String smsCode = await _getUserInput("Enter the SMS code sent to your phone:");
          PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: verificationId, smsCode: smsCode);

          // Sign in with the code
          UserCredential userCredential = await _firebaseAuth.signInWithCredential(credential);
          return userCredential.user;
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          // Auto-retrieved SMS code was not received
          print("Code auto retrieval timed out.");
          return null;
        },
      );
    } catch (e) {
      print("Error logging in: $e");
      return null; // Handle error appropriately
    }
  }

  Future<String> _getUserInput(String prompt) async {
    // Implement a simple dialog or input method to get the SMS code from the user
    // This is a placeholder implementation
    return "123456"; // Replace with actual user input
  }
}
*/

/*import 'package:firebase_auth/firebase_auth.dart';

class FirebaseAuthService {
  FirebaseAuth _auth = FirebaseAuth.instance;

  Future<User?> signInWithPhoneNumber(
      String phoneNumber, String password) async {
    try {
      UserCredential credential = await _auth.signInWithPhoneNumber(phoneNumber:phoneNumber,password:password);
      return credential.user;
    } catch (e) {
      print("Some error occured");
    }
    return null;
  }
}*/

/*import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseAuthService {
  FirebaseAuth _auth = FirebaseAuth.instance;
  FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Function to sign in with phone number and password
  Future<User?> signInWithPhoneNumberAndPassword(
      String phoneNumber, String password) async {
    try {
      // Fetch the user document from Firestore
      var userDoc = await _firestore
          .collection('customer')
          .where('phoneNumber', isEqualTo: phoneNumber)
          .limit(1)
          .get();

      if (userDoc.docs.isEmpty) {
        print('User not found');
        return null;
      }

      var userData = userDoc.docs.first.data();

      // Check if the password matches
      if (userData['password'] == password) {
        // Create a custom token for the user (optional)
        UserCredential userCredential = await _auth.signInAnonymously();
        return userCredential.user;
      } else {
        print('Invalid password');
        return null;
      }
    } catch (e) {
      print("Some error occurred: $e");
      return null;
    }
  }
}
*/
