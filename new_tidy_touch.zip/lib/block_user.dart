import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BlockUser extends StatefulWidget {
  @override
  _BlockUserState createState() => _BlockUserState();
}

class _BlockUserState extends State<BlockUser> {
  final TextEditingController _searchController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  String selectedCategory = 'customers';
  String searchQuery = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFF9F7F7),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              SizedBox(height: 40),
              Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(Icons.arrow_back,
                        color: Color(0xFF112D4E), size: 24),
                  ),
                  SizedBox(width: 10),
                  Text(
                    'Block User',
                    style: GoogleFonts.ptSerif(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF112D4E),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ChoiceChip(
                    label: Text('Customers'),
                    selected: selectedCategory == 'customers',
                    onSelected: (bool selected) {
                      setState(() {
                        selectedCategory = 'customers';
                      });
                    },
                  ),
                  SizedBox(width: 10),
                  ChoiceChip(
                    label: Text('Service Providers'),
                    selected: selectedCategory == 'serviceProviders',
                    onSelected: (bool selected) {
                      setState(() {
                        selectedCategory = 'serviceProviders';
                      });
                    },
                  ),
                ],
              ),
              SizedBox(height: 20),
              TextField(
                onChanged: (value) {
                  setState(() {
                    searchQuery = value.toLowerCase();
                  });
                },
                controller: _searchController,
                decoration: InputDecoration(
                  labelText: 'Search',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: _firestore.collection(selectedCategory).snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }
                    if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}'));
                    }
                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(
                          child: Text(
                              'No ${selectedCategory == 'customers' ? 'customers' : 'service providers'} found.'));
                    }

                    final users = snapshot.data!.docs.where((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      final name = data['name']?.toLowerCase() ?? '';
                      return name.contains(searchQuery);
                    }).toList();

                    return ListView.builder(
                      itemCount: users.length,
                      itemBuilder: (context, index) {
                        final user = users[index];
                        final data = user.data() as Map<String, dynamic>;
                        String displayInfo = '';

                        if (selectedCategory == 'customers') {
                          displayInfo = data['phone number'] ?? 'N/A';
                        } else if (selectedCategory == 'serviceProviders') {
                          displayInfo = data['idNumber'] ?? 'N/A';
                        }

                        return ListTile(
                          title: Text(data['name'] ?? 'N/A'),
                          subtitle: Text(displayInfo),
                          trailing: IconButton(
                            icon: Icon(Icons.block),
                            onPressed: () => _blockUser(user.id),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _blockUser(String id) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Block User'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextButton(
                onPressed: () {
                  _firestore.collection(selectedCategory).doc(id).update({
                    'status': 'blocked',
                    'blockedUntil': DateTime.now().add(Duration(days: 30)),
                  });
                  Navigator.pop(context);
                },
                child: Text('Temporary Block (30 days)'),
              ),
              TextButton(
                onPressed: () {
                  _firestore.collection(selectedCategory).doc(id).update({
                    'status': 'permanently blocked',
                    'blockedUntil': null,
                  });
                  Navigator.pop(context);
                },
                child: Text('Permanent Block'),
              ),
            ],
          ),
        );
      },
    );
  }
}
