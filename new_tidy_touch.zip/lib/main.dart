import 'package:flutter/material.dart';
import 'package:myapp/ChangePhoneNumberPage.dart';
import 'package:myapp/cleaning.dart';
import 'package:myapp/forgot_password_page.dart';
import 'package:myapp/get_code_page.dart';
import 'package:myapp/role_selection_page.dart';
import 'package:myapp/splash_screen.dart';
import 'package:provider/provider.dart';
import 'afterOrder.dart';
import 'login_page.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:firebase_core/firebase_core.dart';

import 'new_password_page.dart';

/*void main() {
  runApp(MyApp());
}*/

/*void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp();
  runApp((MyApp()));
  
}*/

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyDxT2tJt3F5m8C653TnpaXADrOTtwrfaQQ", // Your API Key
      appId: "1:175599045594:android:67bd5c184e043f71780ee3", // Your App ID
      storageBucket: "gs://tidy-touch-c4a0a.appspot.com",
      messagingSenderId: "175599045594", // Your Messaging Sender ID
      projectId: "tidy-touch-c4a0a", // Your Project ID
      databaseURL: 'https://tidy-touch-c4a0a-default-rtdb.firebaseio.com/',
    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => RoleProvider(),
      child: MaterialApp(
        title: 'Your App Name',
        theme: ThemeData(
            // Your theme data
            ),
        home: SplashScreen(), // Set your home page here
      ),
    );
  }
}
