/*import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ViewReports extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFF9F7F7),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              SizedBox(height: 40),
              Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(Icons.arrow_back,
                        color: Color(0xFF112D4E), size: 24),
                  ),
                  SizedBox(width: 10),
                  Text(
                    'User Feedback',
                    style: GoogleFonts.ptSerif(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF112D4E),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16.0),
                  children: [
                    _buildFeedbackCard(
                      context: context,
                      name: 'Ahmad Khaled',
                      phoneNumber: '0772345678',
                      feedback: 'Great service! Highly recommend.',
                    ),
                    _buildFeedbackCard(
                      context: context,
                      name: 'Leen Hosan',
                      phoneNumber: '0798765432',
                      feedback:
                          'Had some issues, but customer support was very helpful.',
                    ),
                    // Add more feedback cards as needed
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeedbackCard({
    required BuildContext context,
    required String name,
    required String phoneNumber,
    required String feedback,
  }) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      color: Colors.white,
      elevation: 5,
      shadowColor: Colors.grey.withOpacity(0.3),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Name: $name',
              style: GoogleFonts.ptSerif(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 5),
            Text(
              'Phone: $phoneNumber',
              style: GoogleFonts.ptSerif(
                fontSize: 18,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Feedback:',
              style: GoogleFonts.ptSerif(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 5),
            Text(
              feedback,
              style: GoogleFonts.ptSerif(
                fontSize: 16,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
*/
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ViewReports extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFF9F7F7),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              SizedBox(height: 40),
              Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(Icons.arrow_back,
                        color: Color(0xFF112D4E), size: 24),
                  ),
                  SizedBox(width: 10),
                  Text(
                    'User Feedback',
                    style: GoogleFonts.ptSerif(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF112D4E),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('ContactUs')
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return Center(
                        child: Text('Error: ${snapshot.error}'),
                      );
                    }

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    List<DocumentSnapshot> feedbackList = snapshot.data!.docs;

                    return ListView.builder(
                      itemCount: feedbackList.length,
                      itemBuilder: (context, index) {
                        var feedback = feedbackList[index];
                        return _buildFeedbackCard(
                          context: context,
                          name: feedback['name'] ?? '',
                          phoneNumber: feedback['number'] ?? '',
                          feedback: feedback['note'] ?? '',
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeedbackCard({
    required BuildContext context,
    required String name,
    required String phoneNumber,
    required String feedback,
  }) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      color: Colors.white,
      elevation: 5,
      shadowColor: Colors.grey.withOpacity(0.3),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Name: $name',
              style: GoogleFonts.ptSerif(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 5),
            Text(
              'Phone: $phoneNumber',
              style: GoogleFonts.ptSerif(
                fontSize: 18,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Feedback:',
              style: GoogleFonts.ptSerif(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 5),
            Text(
              feedback,
              style: GoogleFonts.ptSerif(
                fontSize: 16,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
