import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class ChangePasswordPage extends StatefulWidget {
  @override
  _ChangePasswordPageState createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final _formKey = GlobalKey<FormState>();
  final _oldPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _isLoading = false;
  String? _error;
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  @override
  void dispose() {
    _oldPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _updatePasswordInRealtimeDatabase(String uid) async {
    try {
      final ref = _database.ref();

      // Check if user exists in 'customers' collection
      DataSnapshot customerSnapshot =
          await ref.child('customers').child(uid).get();
      if (customerSnapshot.exists) {
        // Update customer password
        await ref.child('customers').child(uid).update({
          'password': _newPasswordController.text,
        });
        print('Updated password for customer in Realtime Database');
      }
      // If not a customer, assume it's a service provider
      else {
        await ref.child('serviceProviders').child(uid).update({
          'password': _newPasswordController.text,
        });
        print('Updated password for service provider in Realtime Database');
      }
    } catch (e) {
      print('Error updating password in Realtime Database: $e');
      _showErrorDialog('Failed to update password in Realtime Database');
    }
  }

  Future<void> _changePassword() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
      _error = null;
    });

    User? user = FirebaseAuth.instance.currentUser;
    String email = user!.email!;

    try {
      // Re-authenticate the user
      AuthCredential credential = EmailAuthProvider.credential(
          email: email, password: _oldPasswordController.text);

      await user.reauthenticateWithCredential(credential);

      // Update the password in Firebase Auth
      await user.updatePassword(_newPasswordController.text);

      // Determine the appropriate collection based on user type
      String collectionName;
      if (email.contains('serviceprovider')) {
        collectionName = 'serviceProviders';
      } else {
        collectionName = 'customers';
      }

      // Update the password in Firestore
      await FirebaseFirestore.instance
          .collection(collectionName)
          .doc(user.uid)
          .update({'password': _newPasswordController.text});

      // Update the password in Realtime Database
      await _updatePasswordInRealtimeDatabase(user.uid);

      // Success message or navigation
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Password changed successfully')));
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
              title: Text('Error'),
              content: Text(message),
              actions: [
                TextButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    child: Text('OK')),
              ],
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Change Password')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              if (_error != null) ...[
                Text(_error!, style: TextStyle(color: Colors.red)),
                SizedBox(height: 10),
              ],
              TextFormField(
                controller: _oldPasswordController,
                decoration: InputDecoration(labelText: 'Old Password'),
                obscureText: true,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your old password';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _newPasswordController,
                decoration: InputDecoration(labelText: 'New Password'),
                obscureText: true,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a new password';
                  } else if (value.length < 6) {
                    return 'Password must be at least 6 characters';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _confirmPasswordController,
                decoration: InputDecoration(labelText: 'Confirm Password'),
                obscureText: true,
                validator: (value) {
                  if (value != _newPasswordController.text) {
                    return 'Passwords do not match';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              _isLoading
                  ? CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _changePassword, child: Text('Confirm')),
            ],
          ),
        ),
      ),
    );
  }
}
