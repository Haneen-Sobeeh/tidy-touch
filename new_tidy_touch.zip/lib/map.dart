import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MAP extends StatefulWidget {
  const MAP({Key? key}) : super(key: key);

  @override
  State<MAP> createState() => _MAPState();
}

class _MAPState extends State<MAP> {
  static const LatLng _pGooglePlex = LatLng(37.4223, -122.0848);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GoogleMap(
          initialCameraPosition:
              CameraPosition(target: _pGooglePlex, zoom: 13)),
    );
  }
}
