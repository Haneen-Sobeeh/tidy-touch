import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';

const Color backgroundColor = Color(0xFFF9F7F7);
const Color secondaryBackgroundColor = Color(0xFFDBE2EF);
const Color primaryColor = Color(0xFF112D4E);
const Color darkPrimaryColor = Color(0xFF112D4E);

class ContactUsPage extends StatefulWidget {
  @override
  _ContactUsPageState createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _numberController = TextEditingController();
  final TextEditingController _noteController = TextEditingController();
  bool _isSending = false;
  String? _name;
  String? _phoneNumber;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      String userId = user.uid;

      try {
        DocumentSnapshot snapshot = await FirebaseFirestore.instance
            .collection('serviceProviders')
            .doc(userId)
            .get();

        if (snapshot.exists) {
          setState(() {
            _name = snapshot['name'] ?? '';
            _phoneNumber = snapshot['phoneNumber'] ?? '';
            _nameController.text = _name ?? '';
            _numberController.text = _phoneNumber ?? '';
          });
        } else {
          print('No user data found for user ID: $userId');
        }
      } catch (e) {
        print('Failed to load user data: $e');
      }
    } else {
      print('No user is logged in');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Welcome, write us your comments',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.bold,
                      color: darkPrimaryColor),
                ),
                SizedBox(height: 8.0),
                _buildTextField(_nameController, 'Name'),
                SizedBox(height: 8.0),
                _buildTextField(_numberController, 'Phone Number',
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(10),
                    ]),
                SizedBox(height: 8.0),
                _buildTextField(_noteController, 'Write your message here...',
                    maxLines: 5),
                SizedBox(height: 16.0),
                _isSending
                    ? CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(primaryColor))
                    : ElevatedButton.icon(
                        onPressed: _sendMessage,
                        icon: Icon(Icons.send, color: Colors.white),
                        label:
                            Text('Send', style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryColor,
                          padding: EdgeInsets.symmetric(
                              vertical: 16.0, horizontal: 24.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0),
                          ),
                        ),
                      ),
              ],
            ),
          ),
          Positioned(
            top: 30.0,
            left: 10.0,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: primaryColor),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hintText,
      {int maxLines = 1, List<TextInputFormatter>? inputFormatters}) {
    return Container(
      height: maxLines == 1 ? 50.0 : 120.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: secondaryBackgroundColor,
        border: Border.all(color: primaryColor, width: 2),
      ),
      padding: EdgeInsets.symmetric(horizontal: 12.0),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(color: Colors.grey[500]),
          border: InputBorder.none,
        ),
        inputFormatters: inputFormatters,
      ),
    );
  }

  Future<void> _sendMessage() async {
    final String name = _nameController.text.trim();
    final String number = _numberController.text.trim();
    final String note = _noteController.text.trim();

    if (name.isEmpty || number.isEmpty || note.isEmpty) {
      _showAlertDialog('All fields are required.');
    } else if (number.length != 10) {
      _showAlertDialog('Phone number must be 10 digits.');
    } else {
      setState(() {
        _isSending = true;
      });

      FirebaseFirestore.instance.collection('ContactUs').add({
        'name': name,
        'number': number,
        'note': note,
      }).then((_) {
        setState(() {
          _isSending = false;
          _nameController.clear();
          _numberController.clear();
          _noteController.clear();
        });
        _showConfirmationDialog();
      }).catchError((error) {
        setState(() {
          _isSending = false;
        });
        _showAlertDialog('Failed to send message. Please try again later.');
      });
    }
  }

  Future<bool> _validateUser(String name, String number) async {
    try {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('serviceProviders')
          .where('name', isEqualTo: name)
          .where('phoneNumber', isEqualTo: number)
          .get();

      if (snapshot.docs.isNotEmpty) {
        return true;
      }

      snapshot = await FirebaseFirestore.instance
          .collection('customers')
          .where('name', isEqualTo: name)
          .where('phoneNumber', isEqualTo: number)
          .get();

      if (snapshot.docs.isNotEmpty) {
        return true;
      }

      return false;
    } catch (e) {
      print('Failed to validate user: $e');
      return false;
    }
  }

  void _showAlertDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Alert'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Message Sent'),
          content: Text('Thank you for your message!'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
