import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'login_page.dart';

class ServiceOrderPage extends StatefulWidget {
  final String serviceProviderId;

  ServiceOrderPage({required this.serviceProviderId});

  @override
  _ServiceOrderPageState createState() => _ServiceOrderPageState();
}

class _ServiceOrderPageState extends State<ServiceOrderPage> {
  final databaseReference = FirebaseDatabase.instance.ref();
  List<Map<String, dynamic>> orders = [];
  String _userPhoneNumber = UserData.getPhoneNumber();

  @override
  void initState() {
    super.initState();
    fetchOrders();
  }

  void fetchOrders() {
    databaseReference.child('orders').onValue.listen((event) {
      final data = event.snapshot.value as Map?;
      if (data != null) {
        setState(() {
          orders = data.entries
              .map((e) {
                final order = Map<String, dynamic>.from(e.value);
                order['id'] = e.key;
                return order;
              })
              .where((order) => order['state'] != 'accepted')
              .toList();
        });
      }
    });
  }

  void acceptOrder(String orderId) async {
    try {
      print('Attempting to accept order: $orderId');
      await databaseReference
          .child('orders/$orderId')
          .update({'state': 'accepted'});
      print('Order accepted: $orderId');
      await updateServiceProviderStatus(_userPhoneNumber, 'pending');
      print('Service provider status updated to pending');
      setState(() {
        orders.removeWhere((order) => order['id'] == orderId);
      });
      Fluttertoast.showToast(msg: 'Order accepted successfully.');
    } catch (e) {
      print('Failed to accept order: $e');
      Fluttertoast.showToast(msg: 'Failed to accept order.');
    }
  }

  void rejectOrder(String orderId) async {
    try {
      final serviceProviderId = widget.serviceProviderId;
      await databaseReference
          .child('orders/$orderId/serviceProviders/$serviceProviderId')
          .remove();
      setState(() {
        orders.removeWhere((order) => order['id'] == orderId);
      });
      Fluttertoast.showToast(msg: 'Order rejected successfully.');
    } catch (e) {
      print('Failed to reject order: $e');
      Fluttertoast.showToast(msg: 'Failed to reject order.');
    }
  }

  Future<void> updateServiceProviderStatus(
      String phoneNumber, String status) async {
    try {
      print('Fetching service provider with phone number: $phoneNumber');
      final snapshot = await databaseReference
          .child('serviceProviders')
          .orderByChild('phoneNumber')
          .equalTo(phoneNumber)
          .get();
      if (snapshot.exists) {
        final data = snapshot.value as Map?;
        if (data != null) {
          data.forEach((key, value) async {
            print('Updating status for service provider: $key');
            await databaseReference
                .child('serviceProviders/$key')
                .update({'status': status});
            print('Status updated for service provider: $key');
          });
        }
      } else {
        print('No service provider found with phone number: $phoneNumber');
      }
    } catch (e) {
      print('Failed to update service provider status: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Service Orders'),
        titleTextStyle: TextStyle(
          color: Color(0xFF112D4E),
          fontSize: 27,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: orders.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: orders.length,
              itemBuilder: (context, index) {
                final order = orders[index];
                return Card(
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    title: Text('- Customer Number: ${order['phoneNumber']}'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('- Service Type:\n ${order['service type']}'),
                        //Text('Preferred Gender: ${order['preferredGender']}'),
                        Text('- Total Cost: \$${order['totalCost']}'),
                        Text('- Timestamp: ${order['timestamp']}'),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.check, color: Colors.green),
                          onPressed: () => acceptOrder(order['id']),
                        ),
                        IconButton(
                          icon: Icon(Icons.close, color: Colors.red),
                          onPressed: () => rejectOrder(order['id']),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
