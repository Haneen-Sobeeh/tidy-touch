import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/widgets.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:myapp/ConnectWithUsPage.dart';
import 'package:myapp/model.dart';
import 'package:myapp/start_as_SP_page.dart';
import 'intro.dart';
import 'intro_SP.dart';

class UserData3 {
  static String _phoneNumber = '';

  static String getPhoneNumber() {
    return _phoneNumber;
  }

  static void setPhoneNumber(String phoneNumber) {
    _phoneNumber = phoneNumber;
    print('Phone number set to: $_phoneNumber');
  }
}

class ServiceProviderPage extends StatefulWidget {
  @override
  _ServiceProviderPageState createState() => _ServiceProviderPageState();
}

class _ServiceProviderPageState extends State<ServiceProviderPage> {
  PlatformFile? pickedFile;
  final _formKey = GlobalKey<FormState>();
  String _idNumber = '';
  List<String> _selectedServerTypes = [];
  TextEditingController _emailController = TextEditingController();
  TextEditingController _phoneNumberController = TextEditingController();
  TextEditingController _genderController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _confirmPasswordController = TextEditingController();
  TextEditingController _dateOfBirthController = TextEditingController();

  DateTime? _dateOfBirth;
  TextEditingController _pdfTextController = TextEditingController();
  Uint8List? _imageBytes;
  String? _photoError;
  bool _showPassword = false;
  bool _agreeToPrivacySettings = false;
  String _status = '';

  @override
  void initState() {
    super.initState();
    _pdfTextController.text = 'PDF URL';
    _status = '';
  }

  Future<String?> uploadFile() async {
    if (pickedFile == null) return null;
    try {
      final path = 'files/${pickedFile!.name}';
      final ref = FirebaseStorage.instance.ref().child(path);

      if (kIsWeb) {
        final Uint8List? fileBytes = pickedFile!.bytes;
        if (fileBytes != null) {
          await ref.putData(fileBytes);
        }
      } else {
        final file = File(pickedFile!.path!);
        await ref.putFile(file);
      }

      final downloadURL = await ref.getDownloadURL();
      return downloadURL;
    } catch (e) {
      print('Error uploading file: $e');
      return null;
    }
  }

  Future<void> selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;
    setState(() {
      pickedFile = result.files.first;
    });
  }

  Future<void> selectPhoto() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result == null) return;
    setState(() {
      _imageBytes = result.files.first.bytes;
    });
  }

  void saveServiceProviderToFirestore(UserModel user, String pdfUrl,
      String photoUrl, BuildContext context) async {
    try {
      // Check if idNumber or phoneNumber already exists
      bool idOrPhoneExists =
          await checkIdAndPhoneNumberExists(user.idNumber, user.phoneNumber);
      if (idOrPhoneExists) {
        // Show alert dialog for existing idNumber or phoneNumber
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Account Exists'),
              content:
                  Text('The ID number or phone number is already registered.'),
              actions: <Widget>[
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
        return; // Exit save process
      }

      // If idNumber and phoneNumber do not exist, proceed with saving to Firestore
      await FirebaseFirestore.instance.collection('serviceProviders').add({
        'email': user.name,
        'phoneNumber': user.phoneNumber,
        'gender': user.gender,
        'password': user.password,
        'dateOfBirth': user.dateOfBirth,
        'idNumber': user.idNumber,
        'pdfUrl': pdfUrl,
        'photoUrl': photoUrl,
        'serviceTypes': user.serviceTypes,
        'status': _status,
      });

// Save service provider data to Realtime Database

      await FirebaseDatabase.instance
          .reference()
          .child('serviceProviders')
          .child(user.phoneNumber)
          .set({
        'email': user.name,
        'phoneNumber': user.phoneNumber,
        'gender': user.gender,
        'password': user.password,
        'dateOfBirth': user.dateOfBirth?.toIso8601String(),
        'idNumber': user.idNumber,
        'pdfUrl': pdfUrl,
        'photoUrl': photoUrl,
        'serviceTypes': user.serviceTypes,
        'status': _status,
      });
      // Navigate to the next page after successful signup
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => StartPage2()),
      );
    } catch (e) {
      print('Error saving service provider: $e');
      // Handle error case (e.g., show error message to the user)
    }
  }

  Future<bool> checkIdAndPhoneNumberExists(
      String idNumber, String phoneNumber) async {
    try {
      // Check if idNumber or phoneNumber already exists
      var query = await FirebaseFirestore.instance
          .collection('serviceProviders')
          .where('idNumber', isEqualTo: idNumber)
          .get();

      if (query.docs.isNotEmpty) {
        return true; // idNumber already exists
      }

      query = await FirebaseFirestore.instance
          .collection('serviceProviders')
          .where('phoneNumber', isEqualTo: phoneNumber)
          .get();

      return query.docs.isNotEmpty; // true if phoneNumber already exists
    } catch (e) {
      print('Error checking idNumber or phoneNumber: $e');
      return true; // Return true conservatively in case of error
    }
  }

  Future<String?> uploadPhoto() async {
    if (_imageBytes == null) return null;
    try {
      final path = 'photos/${DateTime.now().millisecondsSinceEpoch}.jpg';
      final ref = FirebaseStorage.instance.ref().child(path);
      await ref.putData(_imageBytes!);
      final downloadURL = await ref.getDownloadURL();
      return downloadURL;
    } catch (e) {
      print('Error uploading photo: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          // Background image container
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/1111.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Foreground container with some opacity
          Container(
            color: Color.fromARGB(255, 255, 255, 255)
                .withOpacity(0.85), // Adjust opacity as needed
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      SizedBox(height: 80),
                      Text(
                        'Please Enter Your    Information:',
                        style: TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w700),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromARGB(255, 255, 255, 255),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          controller: _emailController,
                          decoration: InputDecoration(
                            labelText: 'Email',
                            border: InputBorder.none,
                            prefixIcon: Icon(Icons.person),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your Email';
                            } else if (value.length > 100) {
                              return 'The email should be at most 100 characters';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 20),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromARGB(255, 255, 255, 255),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          controller: _phoneNumberController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'Phone Number',
                            prefixIcon:
                                Icon(Icons.phone, color: Color(0xFF112D4E)),
                            border: InputBorder.none,
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            if (value.length != 10) {
                              return 'Phone number must be exactly 10 digits';
                            }
                            if (!value.startsWith('078') &&
                                !value.startsWith('079') &&
                                !value.startsWith('077')) {
                              return 'Phone number must start with 078, 079, or 077';
                            }
                            return null;
                          },
                          maxLength: 10,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(10),
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                        ),
                      ),
                      SizedBox(height: 15),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromARGB(255, 255, 255, 255),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: DropdownButtonFormField<String>(
                          decoration: InputDecoration(
                            labelText: 'Gender',
                            prefixIcon:
                                Icon(Icons.face, color: Color(0xFF112D4E)),
                            border: InputBorder.none,
                          ),
                          value: _genderController.text.isNotEmpty
                              ? _genderController.text
                              : null,
                          dropdownColor: Color(
                              0xFFDBE2EF), // Set your desired dropdown color here
                          items: <String>['', 'Male', 'Female']
                              .map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              _genderController.text = newValue ?? '';
                            });
                          },
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select your gender';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 15),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromARGB(255, 255, 255, 255),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          controller: _passwordController,
                          decoration: InputDecoration(
                            labelText: 'Password',
                            border: InputBorder.none,
                            prefixIcon:
                                Icon(Icons.lock, color: Color(0xFF112D4E)),
                            focusedBorder: InputBorder.none,
                            suffixIcon: IconButton(
                              onPressed: () {
                                setState(() {
                                  _showPassword = !_showPassword;
                                });
                              },
                              icon: Icon(
                                _showPassword
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                            ),
                          ),
                          obscureText: !_showPassword,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your password';
                            }
                            if (value.length < 8) {
                              return 'Password must be at least 8 characters';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 15),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromARGB(255, 255, 255, 255),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          controller: _confirmPasswordController,
                          decoration: InputDecoration(
                            labelText: 'Confirm Password',
                            prefixIcon:
                                Icon(Icons.lock, color: Color(0xFF112D4E)),
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            suffixIcon: IconButton(
                              onPressed: () {
                                setState(() {
                                  _showPassword = !_showPassword;
                                });
                              },
                              icon: Icon(
                                _showPassword
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                            ),
                          ),
                          obscureText: !_showPassword,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please confirm your password';
                            }
                            if (value != _passwordController.text) {
                              return 'Passwords do not match';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 15),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromARGB(255, 255, 255, 255),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: 'ID Number',
                            border: InputBorder.none,
                            prefixIcon: Icon(Icons.format_list_numbered),
                          ),
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(10),
                          ],
                          onChanged: (value) {
                            setState(() {
                              _idNumber = value;
                            });
                          },
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your ID number';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 20),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromARGB(255, 255, 255, 255),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          controller: _dateOfBirthController,
                          decoration: InputDecoration(
                            labelText: 'Date of Birth',
                            prefixIcon: Icon(Icons.date_range,
                                color: Color(0xFF112D4E)),
                            border: InputBorder.none,
                          ),
                          readOnly: true,
                          onTap: () async {
                            DateTime? selectedDate = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(1900),
                              lastDate: DateTime.now(),
                              builder: (BuildContext context, Widget? child) {
                                return Theme(
                                  data: ThemeData.light().copyWith(
                                    colorScheme: ColorScheme.light(
                                      primary: Color(
                                          0xFF5483b3), // Header background color
                                      onPrimary:
                                          Colors.white, // Header text color
                                      onSurface:
                                          Color(0xFF112D4E), // Body text color
                                    ),
                                    dialogBackgroundColor: Color.fromARGB(
                                        255, 255, 255, 255), // Background color
                                  ),
                                  child: child!,
                                );
                              },
                            );
                            if (selectedDate != null) {
                              setState(() {
                                _dateOfBirth = selectedDate;
                                _dateOfBirthController.text =
                                    DateFormat('dd/MM/yyyy')
                                        .format(_dateOfBirth!);
                              });
                            }
                          },
                          validator: (value) {
                            if (_dateOfBirth == null) {
                              return 'Please select your date of birth';
                            }
                            // Check if age is 18 years or older
                            DateTime currentDate = DateTime.now();
                            DateTime minimumDate = DateTime(
                                currentDate.year - 18,
                                currentDate.month,
                                currentDate.day);
                            if (_dateOfBirth!.isAfter(minimumDate)) {
                              return 'Minimum age requirement is 18 years';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(height: 15),
                      Text(
                        'Please Upload Your Photo:',
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w500),
                      ),
                      SizedBox(height: 15),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: selectPhoto,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.photo,
                                    color: Color(0xFF112D4E),
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    'Select Photo',
                                    style: TextStyle(color: Color(0xFF112D4E)),
                                  ),
                                ],
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xFFDBE2EF),
                                padding: EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(100),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 0),
                          // Display the selected photo
                          if (_imageBytes != null)
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: MemoryImage(
                                      _imageBytes!), // Display the image from _imageBytes
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Please Upload Your Criminal Record Document (Non-conviction Record):',
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w500),
                      ),
                      SizedBox(height: 15),
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color.fromARGB(255, 255, 255, 255),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0xFF112D4E).withOpacity(0.5),
                                    spreadRadius: 2,
                                    blurRadius: 5,
                                    offset: Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: Text(
                                pickedFile != null
                                    ? pickedFile!.name
                                    : 'No file selected',
                                style: TextStyle(fontSize: 16),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                          SizedBox(width: 10),
                          ElevatedButton(
                            onPressed: selectFile,
                            child: Text(
                              'Upload PDF',
                              style: TextStyle(
                                color: Colors
                                    .white, // Text color for better contrast
                                fontSize: 16, // Optional: Adjust font size
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              foregroundColor:
                                  Color.fromARGB(255, 255, 255, 255),
                              backgroundColor:
                                  Color(0xFF5483b3), // Color for text and icon
                              padding: EdgeInsets.symmetric(
                                  vertical: 15,
                                  horizontal: 20), // Adjust padding
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100),
                              ),
                              elevation:
                                  5, // Optional: Add shadow for a raised effect
                            ),
                          ),
                        ],
                      ),
                      if (_photoError != null)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Text(
                            _photoError!,
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      SizedBox(height: 20),
                      MultiSelectDialogField<String>(
                        items: [
                          MultiSelectItem<String>(
                            'Kitchen',
                            'Kitchen',
                          ),
                          MultiSelectItem<String>('Room', 'Room'),
                          MultiSelectItem<String>('Bedroom', 'Bedroom'),
                          MultiSelectItem<String>('Bathroom', 'Bathroom'),
                          MultiSelectItem<String>(
                              'House Garden', 'House Garden'),
                          MultiSelectItem<String>(
                              'The Outdoor Stairs', 'The Outdoor Stairs'),
                        ],
                        decoration: BoxDecoration(
                          color: Color(0xFFDBE2EF),
                          borderRadius: BorderRadius.circular(15.0),
                          border: Border.all(color: Color(0xFF112D4E)),
                        ),
                        title: Text(
                          "Select Type of Service You Provide:",
                          style: TextStyle(
                              color: Color(0xFF112D4E),
                              backgroundColor:
                                  Color.fromARGB(255, 255, 255, 255)),
                        ),
                        backgroundColor: Color.fromARGB(255, 255, 255, 255),
                        listType: MultiSelectListType.CHIP,
                        selectedColor: Color(0xFF5483b3),
                        itemsTextStyle: TextStyle(
                            color: Color(0xFF112D4E),
                            backgroundColor:
                                Color.fromARGB(255, 255, 255, 255)),
                        selectedItemsTextStyle: const TextStyle(
                            color: Color.fromARGB(255, 255, 255, 255)),
                        initialValue: _selectedServerTypes,
                        onConfirm: (values) {
                          setState(() {
                            _selectedServerTypes = values;
                          });
                        },
                      ),
                      SizedBox(height: 20),
                      CheckboxListTile(
                        title: Text(
                          'I agree to the privacy settings',
                          style: GoogleFonts.ptSerif(
                              fontSize: 20, fontWeight: FontWeight.w700),
                        ),
                        value: _agreeToPrivacySettings,
                        onChanged: (bool? value) async {
                          // Show the AlertDialog
                          bool? result = await showDialog<bool>(
                            context: context,
                            builder: (BuildContext context) {
                              return Theme(
                                  data: ThemeData.light().copyWith(
                                    primaryColor:
                                        Color(0xFF5483b3), // Header color
                                    hintColor:
                                        Color(0xFF5483b3), // Button color
                                    dialogBackgroundColor: Color.fromARGB(
                                        255,
                                        255,
                                        255,
                                        255), // Dialog background color
                                    textTheme: TextTheme(
                                      titleLarge: TextStyle(
                                          color: Color(
                                              0xFF112D4E)), // Title text color
                                      bodyMedium: TextStyle(
                                          color: Color(
                                              0xFF112D4E)), // Content text color
                                    ),
                                    buttonTheme: ButtonThemeData(
                                      textTheme: ButtonTextTheme.primary,
                                    ),
                                  ),
                                  child: AlertDialog(
                                    title: Text(
                                      'I Agree to',
                                      style: TextStyle(
                                          color: Color(0xFF112D4E),
                                          fontSize: 25),
                                    ),
                                    content: Text(
                                        'Data Collection: We gather your personal details for service bookings and payments.\n\n'
                                        'Security: We implement strong security measures to protect your data from unauthorized access.\n\n'
                                        'User Rights: You can access, modify, or delete your personal data at any time.\n\n'
                                        'Policy Updates: We will notify you of any changes to our policies.\n\n'
                                        'Home Visit Security: Our team maintains strict protocols to ensure safety during service visits.\n\n'
                                        'Damage Liability: We are fully responsible for any damages during our services and will resolve issues promptly.'),
                                    actions: <Widget>[
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          foregroundColor: Colors.white,
                                          backgroundColor: Color.fromARGB(
                                              255, 231, 12, 33), // Text color
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                100), // Rounded corners
                                          ),
                                        ),
                                        child: Text(
                                          'Reject',
                                          style: TextStyle(fontSize: 18),
                                        ),
                                        onPressed: () {
                                          Navigator.of(context).pop(
                                              false); // Return false to indicate Reject
                                        },
                                      ),
                                      SizedBox(
                                          width:
                                              10), // Add spacing between buttons
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          foregroundColor: Colors.white,
                                          backgroundColor: Color.fromARGB(
                                              255, 0, 177, 68), // Text color
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                100), // Rounded corners
                                          ),
                                        ),
                                        child: Text(
                                          'Accept',
                                          style: TextStyle(fontSize: 18),
                                        ),
                                        onPressed: () {
                                          Navigator.of(context).pop(
                                              true); // Return true to indicate Accept
                                        },
                                      ),
                                    ],
                                  ));
                            },
                          );

                          // Check the result and update the checkbox accordingly
                          if (result != null) {
                            setState(() {
                              _agreeToPrivacySettings =
                                  result; // Update only if result is not null
                            });
                          }
                        },
                        controlAffinity: ListTileControlAffinity.leading,
                        activeColor: Color(
                            0xFF3F72AF), // Change color when checked to 3F72AF
                      ),
                      ElevatedButton(
                        onPressed: _agreeToPrivacySettings
                            ? () async {
                                if (_formKey.currentState!.validate()) {
                                  if (_imageBytes == null) {
                                    setState(() {
                                      _photoError = 'Please upload your photo.';
                                    });
                                  } else if (pickedFile == null) {
                                    setState(() {
                                      _photoError =
                                          'Please upload your criminal record document.';
                                    });
                                  } else {
                                    setState(() {
                                      _photoError = null;
                                    });
                                    // Proceed with signup process
                                    String? downloadURL =
                                        await uploadFile(); // For PDF
                                    String? photoUrl =
                                        await uploadPhoto(); // For Photo
                                    if (downloadURL != null &&
                                        photoUrl != null) {
                                      // Set the phone number here
                                      UserData3.setPhoneNumber(
                                          _phoneNumberController.text);

                                      // Create a UserModel instance
                                      UserModel user = UserModel(
                                        name: _emailController.text,
                                        phoneNumber:
                                            _phoneNumberController.text,
                                        dateOfBirth: _dateOfBirth!,
                                        gender: _genderController.text,
                                        password: _passwordController.text,
                                        idNumber: _idNumber,
                                        serviceTypes: _selectedServerTypes,
                                        pdfUrl: '',
                                      );

                                      // Save service provider data to Firestore

                                      saveServiceProviderToFirestore(
                                          user, downloadURL, photoUrl, context);
                                      _createUser(context);

                                      // Use the phone number elsewhere if needed
                                      String _userPhoneNumber3 =
                                          UserData3.getPhoneNumber();
                                    } else {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title: Text('Error'),
                                            content: Text(
                                                'Failed to upload file or photo.'),
                                            actions: <Widget>[
                                              TextButton(
                                                child: Text('OK'),
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                  }
                                }
                              }
                            : null,
                        child: Text(
                          'Sign Up',
                          style: TextStyle(
                              color: Color.fromARGB(255, 255, 255, 255),
                              fontSize: 25),
                        ),
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          backgroundColor: Color(0xFF5483b3),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(100),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 30.0,
            left: 10.0,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Color(0xFF112D4E)),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _createUser(BuildContext context) async {
    if (!_formKey.currentState!.validate()) {
      // If form validation fails, return early
      return;
    }

    try {
      final UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      // Get the User object from the UserCredential
      User? user = userCredential.user;
      if (user != null) {
        // Successfully created user
        print('User created: ${user.uid}');

        // Store additional user info in Firestore
        await _addUserToFirestore(
          user,
          _phoneNumberController.text.trim(),
          _genderController.text.trim(),
          _dateOfBirthController.text.trim(),
          _passwordController.text.trim(),
          _idNumber,
          _selectedServerTypes,
          context,
        );
      }
    } catch (e) {
      print('Failed to create user: $e');
      _showErrorDialog('Failed to create user: $e');
    }
  }

  Future<void> _addUserToFirestore(
      User user,
      String phoneNumber,
      String gender,
      String dateOfBirth,
      String password,
      String idNumber,
      List<String> serviceTypes,
      BuildContext context) async {
    try {
      // Select and upload PDF file
      String? pdfUrl = await uploadFile();
      if (pdfUrl == null) {
        print('PDF upload failed.');
        return; // Exit if PDF upload fails
      }

      // Select and upload photo
      String? photoUrl = await uploadPhoto();
      if (photoUrl == null) {
        print('Photo upload failed.');
        return; // Exit if photo upload fails
      }

      // Proceed with saving to Firestore
      await FirebaseFirestore.instance
          .collection('serviceProviders')
          .doc(user.uid)
          .set({
        'email': user.email,
        'phoneNumber': phoneNumber,
        'gender': gender,
        'password': password,
        'dateOfBirth': dateOfBirth,
        'idNumber': idNumber,
        'serviceTypes': serviceTypes,
        'role': 'serviceProvider',
        'status': _status,
        'pdfUrl': pdfUrl, // Add PDF URL
        'photoUrl': photoUrl, // Add photo URL
      });

      print('User added to Firestore');

      // Optionally, save user data to Realtime Database
      await FirebaseDatabase.instance
          .reference()
          .child('serviceProviders')
          .child(user.uid)
          .set({
        'email': user.email,
        'phoneNumber': phoneNumber,
        'gender': gender,
        'password': password,
        'dateOfBirth': dateOfBirth,
        'idNumber': idNumber,
        'serviceTypes': serviceTypes,
        'role': 'serviceProvider',
        'status': _status,
        'pdfUrl': pdfUrl, // Add PDF URL
        'photoUrl': photoUrl, // Add photo URL
      });

      print('User added to Realtime Database');
    } catch (e) {
      print('Error adding user: $e');
    }
  }

  /*void showPhoneNumberExistsDialog(String phoneNumber) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Phone Number Exists'),
          content: Text('The phone number $phoneNumber is already registered.'),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }*/
}
