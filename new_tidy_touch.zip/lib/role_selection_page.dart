/*import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/service_provider_page.dart';
import 'package:provider/provider.dart';
import 'create_account_page_cutomer.dart';
import 'intro.dart';
import 'intro_SP.dart';

class RoleSelectionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            color: Color(0xFFF9F7F7),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(height: 50),
                  Text(
                    'Please select your type:',
                    style: GoogleFonts.ptSerif(
                        fontSize: 26, fontWeight: FontWeight.w700),
                    textAlign: TextAlign.left,
                  ),
                  SizedBox(height: 30),
                  Container(
                    width: 400,
                    height: 400,
                    decoration: BoxDecoration(
                      color: Color(0xFF112D4E),
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'Sign Up As: ',
                            style: GoogleFonts.ptSerif(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFFDBE2EF)),
                          ),
                          SizedBox(height: 30),
                          ElevatedButton(
                            onPressed: () {
                              Provider.of<RoleProvider>(context, listen: false)
                                  .setRole('Customer');

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      CreateAccountPageCustomer(),
                                ),
                              );
                            },
                            child: Text('Customer',
                                style: GoogleFonts.ptSerif(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF112D4E))),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFDBE2EF),
                              textStyle: TextStyle(color: Colors.black),
                              fixedSize: Size(250, 100),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 40, vertical: 15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                            ),
                          ),
                          SizedBox(height: 20),
                          ElevatedButton(
                            onPressed: () {
                              Provider.of<RoleProvider>(context, listen: false)
                                  .setRole('Service Provider');

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ServiceProviderPage(),
                                ),
                              );
                            },
                            child: Text('Service Provider',
                                style: GoogleFonts.ptSerif(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF112D4E))),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFDBE2EF),
                              fixedSize: Size(250, 100),
                              textStyle: TextStyle(color: Colors.black),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: 30.0,
            left: 10.0,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Color(0xFF112D4E)),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class RoleProvider extends ChangeNotifier {
  String _role = '';

  String get role => _role;

  void setRole(String role) {
    _role = role;
    notifyListeners();
  }
}*/
