import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/services.dart';

import 'cleaning.dart';
import 'intro.dart';

class CreateAccountPageCustomer extends StatefulWidget {
  @override
  _CreateAccountPageState createState() => _CreateAccountPageState();
}

class _CreateAccountPageState extends State<CreateAccountPageCustomer> {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _phoneNumber = '';
  String _gender = '';
  DateTime? _dateOfBirth;
  String _password = '';
  String _confirmPassword = '';
  bool _showPassword = false;
  bool _agreeToPrivacySettings = false;

  final TextEditingController _dateOfBirthController = TextEditingController();

  CollectionReference customers =
      FirebaseFirestore.instance.collection('customers');
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> _signUp() async {
    try {
      // Check if phone number already exists in customers collection
      var customerSnapshot = await _firestore
          .collection('customers')
          .where('phone number', isEqualTo: _phoneNumber)
          .get();

      if (customerSnapshot.docs.isNotEmpty) {
        _showErrorDialog('Phone number already registered as a customer');
        return; // Prevent moving to the next page
      }

      // If phone number doesn't exist, proceed with registration
      if (_formKey.currentState!.validate()) {
        await _createUser().then((_) {
          // Only navigate if user creation is successful
        }).catchError((error) {
          _showErrorDialog('Failed to create user: $error');
        });
      }
    } catch (e) {
      _showErrorDialog('An error occurred: $e');
    }
  }

  /*void addUser(String role) {
    customers
        .add({
          "email": _email,
          "phone number": _phoneNumber,
          "gender": _gender,
          "dateofbirth": _dateOfBirth,
          "password": _password,
          "role": role, // Saving the role to Firestore
        })
        .then((value) => print("User Added"))
        .catchError((error) => print("Failed to add user: $error"));
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          // Background image container
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/1111.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 255, 255)
                .withOpacity(0.85), // Adjust opacity as needed
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    SizedBox(height: 70),
                    Text(
                      'Please Enter Your     Information:',
                      style:
                          TextStyle(fontSize: 26, fontWeight: FontWeight.w700),
                      textAlign: TextAlign.left,
                    ),
                    SizedBox(height: 10),
                    SizedBox(height: 10),
                    Container(
                      // Add a container around TextFormField for Your Name
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: Color.fromARGB(255, 255, 255, 255),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF112D4E).withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          labelText: 'Your Email',
                          prefixIcon:
                              Icon(Icons.person, color: Color(0xFF112D4E)),
                          border: InputBorder.none,
                        ),
                        onChanged: (value) {
                          setState(() {
                            _email = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your Email';
                          } else if (value.length > 100) {
                            return 'The email should be at most 100 characters';
                          } else if (!RegExp(
                                  r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
                              .hasMatch(value)) {
                            return 'Please enter a valid email address';
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(height: 15),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: Color.fromARGB(255, 255, 255, 255),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF112D4E).withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Phone Number',
                          prefixIcon:
                              Icon(Icons.phone, color: Color(0xFF112D4E)),
                          border: InputBorder.none,
                        ),
                        onChanged: (value) {
                          setState(() {
                            _phoneNumber = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your phone number';
                          }
                          if (value.length != 10) {
                            // Changed to 10 digits
                            return 'Phone number must be exactly 10 digits';
                          }
                          if (!value.startsWith('078') &&
                              !value.startsWith('079') &&
                              !value.startsWith('077')) {
                            return 'Phone number must start with 078, 079, or 077';
                          }
                          return null;
                        },
                        maxLength: 10, // Limit the input to 10 digits
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(
                              10), // Limit to 10 digits
                          FilteringTextInputFormatter
                              .digitsOnly, // Only allow digits
                        ],
                      ),
                    ),
                    SizedBox(height: 15),
                    Container(
                      // Add a container around DropdownButtonFormField for Gender
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: Color.fromARGB(255, 255, 255, 255),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF112D4E).withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: DropdownButtonFormField<String>(
                        decoration: InputDecoration(
                          labelText: 'Gender',
                          prefixIcon:
                              Icon(Icons.face, color: Color(0xFF112D4E)),
                          border: InputBorder.none,
                        ),
                        value: _gender.isNotEmpty ? _gender : null,
                        dropdownColor: Color(0xFFDBE2EF),
                        items:
                            <String>['', 'Male', 'Female'].map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          setState(() {
                            _gender = newValue!;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please select your gender';
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(height: 15),
                    Container(
                      // Add a container around TextFormField for Date of Birth
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: Color.fromARGB(255, 255, 255, 255),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF112D4E).withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: TextFormField(
                        controller: _dateOfBirthController,
                        decoration: InputDecoration(
                          labelText: 'Date of Birth',
                          prefixIcon:
                              Icon(Icons.date_range, color: Color(0xFF112D4E)),
                          border: InputBorder.none,
                        ),
                        readOnly: true,
                        onTap: () async {
                          DateTime? selectedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime.now(),
                            builder: (BuildContext context, Widget? child) {
                              return Theme(
                                data: ThemeData.light().copyWith(
                                  colorScheme: ColorScheme.light(
                                    primary: Color(
                                        0xFF5483b3), // Header background color
                                    onPrimary:
                                        Colors.white, // Header text color
                                    onSurface:
                                        Color(0xFF112D4E), // Body text color
                                  ),
                                  dialogBackgroundColor: Color.fromARGB(
                                      255, 255, 255, 255), // Background color
                                ),
                                child: child!,
                              );
                            },
                          );
                          if (selectedDate != null) {
                            setState(() {
                              _dateOfBirth = selectedDate;
                              _dateOfBirthController.text =
                                  DateFormat('dd/MM/yyyy')
                                      .format(_dateOfBirth!);
                            });
                          }
                        },
                        validator: (value) {
                          if (_dateOfBirth == null) {
                            return 'Please select your date of birth';
                          }
                          // Check if age is 18 years or older
                          DateTime currentDate = DateTime.now();
                          DateTime minimumDate = DateTime(currentDate.year - 18,
                              currentDate.month, currentDate.day);
                          if (_dateOfBirth!.isAfter(minimumDate)) {
                            return 'Minimum age requirement is 18 years';
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(height: 15),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: Color.fromARGB(255, 255, 255, 255),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF112D4E).withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Password',
                          border: InputBorder.none,
                          prefixIcon:
                              Icon(Icons.lock, color: Color(0xFF112D4E)),
                          focusedBorder: InputBorder.none,
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                _showPassword = !_showPassword;
                              });
                            },
                            icon: Icon(
                              _showPassword
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                          ),
                        ),
                        obscureText: !_showPassword,
                        onChanged: (value) {
                          setState(() {
                            _password = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your password';
                          }
                          if (value.length < 8) {
                            return 'Password must be at least 8 characters';
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(height: 15),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: Color.fromARGB(255, 255, 255, 255),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFF112D4E).withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Confirm Password',
                          prefixIcon:
                              Icon(Icons.lock, color: Color(0xFF112D4E)),
                          border: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                _showPassword = !_showPassword;
                              });
                            },
                            icon: Icon(
                              _showPassword
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                          ),
                        ),
                        obscureText:
                            !_showPassword, // Notice the ! operator here
                        onChanged: (value) {
                          setState(() {
                            _confirmPassword = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please confirm your password';
                          }
                          if (value != _password) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(height: 15),
                    CheckboxListTile(
                      title: Text(
                        'I agree to the privacy settings',
                        style: GoogleFonts.ptSerif(
                            fontSize: 20, fontWeight: FontWeight.w700),
                      ),
                      value: _agreeToPrivacySettings,
                      onChanged: (bool? value) async {
                        // Show the AlertDialog
                        bool? result = await showDialog<bool>(
                          context: context,
                          builder: (BuildContext context) {
                            return Theme(
                              data: ThemeData.light().copyWith(
                                primaryColor: Color(0xFF5483b3), // Header color
                                hintColor: Color(0xFF5483b3), // Button color
                                dialogBackgroundColor: Color.fromARGB(255, 255,
                                    255, 255), // Dialog background color
                                textTheme: TextTheme(
                                  titleLarge: TextStyle(
                                      color: Color(
                                          0xFF112D4E)), // Title text color
                                  bodyMedium: TextStyle(
                                      color: Color(
                                          0xFF112D4E)), // Content text color
                                ),
                                buttonTheme: ButtonThemeData(
                                  textTheme: ButtonTextTheme.primary,
                                ),
                              ),
                              child: AlertDialog(
                                title: Text(
                                  'I Agree to',
                                  style: TextStyle(
                                      color: Color(0xFF112D4E), fontSize: 25),
                                ),
                                content: Text(
                                    'Data Collection: We gather your personal details for service bookings and payments.\n\n'
                                    'Security: We implement strong security measures to protect your data from unauthorized access.\n\n'
                                    'User Rights: You can access, modify, or delete your personal data at any time.\n\n'
                                    'Policy Updates: We will notify you of any changes to our policies.\n\n'
                                    'Home Visit Security: Our team maintains strict protocols to ensure safety during service visits.\n\n'
                                    'Damage Liability: We are fully responsible for any damages during our services and will resolve issues promptly.'),
                                actions: <Widget>[
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      foregroundColor: Colors.white,
                                      backgroundColor: Color.fromARGB(
                                          255, 231, 12, 33), // Text color
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            100), // Rounded corners
                                      ),
                                    ),
                                    child: Text(
                                      'Reject',
                                      style: TextStyle(fontSize: 18),
                                    ),
                                    onPressed: () {
                                      Navigator.of(context).pop(
                                          false); // Return false to indicate Reject
                                    },
                                  ),
                                  SizedBox(
                                      width: 10), // Add spacing between buttons
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      foregroundColor: Colors.white,
                                      backgroundColor: Color.fromARGB(
                                          255, 0, 177, 68), // Text color
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            100), // Rounded corners
                                      ),
                                    ),
                                    child: Text(
                                      'Accept',
                                      style: TextStyle(fontSize: 18),
                                    ),
                                    onPressed: () {
                                      Navigator.of(context).pop(
                                          true); // Return true to indicate Accept
                                    },
                                  ),
                                ],
                              ),
                            );
                          },
                        );

                        // Update _agreeToPrivacySettings based on the result
                        setState(() {
                          _agreeToPrivacySettings =
                              result ?? false; // Set to false if result is null
                        });
                      },
                      controlAffinity: ListTileControlAffinity.leading,
                      activeColor: Color(
                          0xFF3F72AF), // Change color when checked to 3F72AF
                    ),
                    ElevatedButton(
                      onPressed: _agreeToPrivacySettings
                          ? () {
                              _signUp();
                            }
                          : null,
                      child: Text(
                        'Create Account',
                        style: TextStyle(
                            color: Color.fromARGB(255, 255, 255, 255),
                            fontSize: 30),
                      ),
                      style: ElevatedButton.styleFrom(
                        fixedSize: Size(250, 60),
                        backgroundColor: Color(0xFF5483b3),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(100),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 30.0, // Position from the top
            left: 10.0, // Position from the left
            child: IconButton(
              icon: Icon(Icons.arrow_back,
                  color: Colors.black), // Use black color for the back icon
              onPressed: () {
                Navigator.pop(
                    context); // Navigate back when the back icon is clicked
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _createUser() async {
    try {
      final UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _email,
        password: _password,
      );

      User? user = userCredential.user;
      if (user != null) {
        // Successfully created user
        print('User created: ${user.uid}');
        // Store additional user info in Firestore and Realtime Database
        await _addUserToFirestore(user);
        await _addUserToRealtimeDatabase(user);

        // Navigate to CleaningPage after successful sign-up
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => StartPage()),
        );
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        _showErrorDialog('This email is already registered.');
      } else {
        _showErrorDialog('Failed to create user: $e');
      }
    } catch (e) {
      print('Failed to create user: $e');
      _showErrorDialog('Failed to create user: $e');
    }
  }

  Future<void> _addUserToFirestore(User user) async {
    try {
      await FirebaseFirestore.instance
          .collection('customers')
          .doc(user.uid)
          .set({
        'email': user.email,
        'phone number': _phoneNumber,
        'password': _password,
        'gender': _gender,
        'dateOfBirth': _dateOfBirth,
        'role': 'customer',
      });

      print('User added to Firestore');
    } catch (e) {
      print('Failed to add user to Firestore: $e');
      _showErrorDialog('Failed to add user to Firestore: $e');
    }
  }

  Future<void> _addUserToRealtimeDatabase(User user) async {
    try {
      await FirebaseDatabase.instance
          .reference()
          .child('customers')
          .child(user.uid)
          .set({
        'email': user.email,
        'phone number': _phoneNumber,
        'password': _password,
        'gender': _gender,
        'dateOfBirth': _dateOfBirth,
        'role': 'customer',
      });

      print('User added to Realtime Database');
    } catch (e) {
      print('Failed to add user to Realtime Database: $e');
      _showErrorDialog('Failed to add user to Realtime Database: $e');
    }
  }
}
