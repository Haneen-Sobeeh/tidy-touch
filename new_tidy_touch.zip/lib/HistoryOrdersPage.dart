import 'dart:math';
import 'package:flutter/material.dart';
import 'ordermodel.dart';

// Define your color scheme
const Color backgroundColor = Color(0xFFF9F7F7);
const Color secondaryBackgroundColor = Color(0xFFDBE2EF);
const Color primaryColor = Color(0xFF3F72AF);
const Color darkPrimaryColor = Color(0xFF112D4E);

class HistoryOrdersPage extends StatelessWidget {
  final List<String> Name = ['haneen', 'ali'];

  final List<Order> orders = [
    Order(
      day: '30/6/2024',
      value: 10,
      name: '',
      contactNumber: '0788888888',
      image: '',
    ),
    Order(
      day: '30/6/2024',
      value: 19,
      name: '',
      contactNumber: '0788888881',
      image: '',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final random = Random();

    for (var order in orders) {
      order.serviceProvider = Name[random.nextInt(Name.length)];
    }

    return Scaffold(
      body: Stack(
        children: [
          Padding(
            padding: EdgeInsets.only(top: 70.0), // Add padding at the top
            child: ListView.builder(
              itemCount: orders.length,
              itemBuilder: (context, index) {
                final order = orders[index];
                return InkWell(
                  onTap: () {
                    // Navigate to a detailed view or perform an action
                  },
                  child: Container(
                    margin:
                        EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                    decoration: BoxDecoration(
                      color: secondaryBackgroundColor,
                      borderRadius: BorderRadius.circular(12.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(Icons.home, color: primaryColor, size: 40.0),
                          SizedBox(width: 16.0),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  ' ${order.serviceProvider}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18.0,
                                    color: darkPrimaryColor,
                                  ),
                                ),
                                SizedBox(height: 8.0),
                                Text(
                                  'Contact Number: ${order.contactNumber}',
                                  style: TextStyle(
                                      fontSize: 16.0, color: darkPrimaryColor),
                                ),
                                SizedBox(height: 8.0),
                                Text(
                                  'Date of Service: ${order.day}',
                                  style: TextStyle(
                                      fontSize: 16.0, color: darkPrimaryColor),
                                ),
                                SizedBox(height: 8.0),
                                Text(
                                  'Price Paid: \$${order.value.toStringAsFixed(2)}',
                                  style: TextStyle(
                                      fontSize: 16.0, color: darkPrimaryColor),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Positioned(
            top: 30.0,
            left: 10.0,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Color(0xFF112D4E)),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
}
