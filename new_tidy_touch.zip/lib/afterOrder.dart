import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'cleaning.dart';
import 'login_page.dart';
import 'map.dart';

class AfterOrderPage extends StatefulWidget {
  @override
  _AfterOrderPageState createState() => _AfterOrderPageState();
}

class _AfterOrderPageState extends State<AfterOrderPage> {
  bool _isWaiting = true;
  Map<String, dynamic>? _serviceProviderData;
  String _orderId = ''; // Initialize with an empty string

  @override
  void initState() {
    super.initState();
    _showBottomAlertBox();
  }

  void _showBottomAlertBox() {
    WidgetsBinding.instance?.addPostFrameCallback((_) {
      showModalBottomSheet(
        context: context,
        isDismissible: false,
        builder: (BuildContext context) {
          return StatefulBuilder(
            builder: (BuildContext context, StateSetter setModalState) {
              _updateBottomSheet = setModalState;
              return Container(
                padding: const EdgeInsets.all(16),
                height: MediaQuery.of(context).size.height * 0.4,
                color: const Color(0xFF112D4E),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: _isWaiting
                      ? _buildWaitingContent()
                      : _buildProviderContent(),
                ),
              );
            },
          );
        },
      );

      Timer(const Duration(seconds: 1), () {
        _fetchLatestOrderAndProvider();
        // _fetchLatestOrderAndProvider1();
      });
    });
  }

  StateSetter? _updateBottomSheet;

  List<Widget> _buildWaitingContent() {
    return [
      const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(width: 10),
          Flexible(
            child: Text(
              'Waiting for service provider, please wait',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
      const SizedBox(height: 20),
      const CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
      ),
    ];
  }

  List<Widget> _buildProviderContent() {
    return _serviceProviderData != null
        ? [
            Container(
              height: MediaQuery.of(context).size.height * 0.3,
              width: 500,
              color: const Color(0xFF112D4E),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      backgroundImage:
                          NetworkImage(_serviceProviderData?['photoUrl']),
                      radius: 35, // Adjusted to a smaller size
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Service Provider Found:',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Name: ${_serviceProviderData?['name']}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      'Phone Number: ${_serviceProviderData?['phoneNumber']}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () {
                        // Add your confirm order functionality here
                        _confirmOrder();
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: const Color(0xFF112D4E),
                        backgroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        textStyle: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      child: const Text('Continue'),
                    ),
                  ],
                ),
              ),
            ),
          ]
        : [
            Container(
              height: MediaQuery.of(context).size.height * 0.3,
              color: const Color(0xFF112D4E),
              child: const Center(
                child: Text(
                  'No service provider found',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
          ];
  }

  void _confirmOrder() {
    setState(() {
      _isWaiting = true;
      // Generate a random 6-digit code
    });

    // Close current bottom sheet
    Navigator.of(context).pop();

    // Save service provider information to history collection
    if (_serviceProviderData != null) {
      saveToHistoryCollection(_serviceProviderData!);
    }

    // Show new bottom sheet with countdown timer and random code
    _showConfirmationBottomSheet();
  }

  /* Future<void> _fetchLatestOrderAndProvider1() async {
    print('Fetching latest orders...');
    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Fetch all orders sorted by timestamp in descending order
      QuerySnapshot ordersSnapshot = await firestore
          .collection('orders')
          .orderBy('timestamp', descending: true)
          .get();

      if (ordersSnapshot.docs.isEmpty) {
        print('No orders found');
        setState(() {
          _isWaiting = false;
          _serviceProviderData = null;
        });
        if (_updateBottomSheet != null) {
          _updateBottomSheet!(() {});
        }
        return;
      }

      // Map to store the latest order for each phone number
      Map<String, dynamic> latestOrdersMap = {};

      // Iterate through each order to find the latest order for each phone number
      for (var orderDoc in ordersSnapshot.docs) {
        String phoneNumber = orderDoc['phoneNumber'];

        // Check if we already have the latest order for this phone number
        if (!latestOrdersMap.containsKey(phoneNumber)) {
          latestOrdersMap[phoneNumber] = orderDoc;
        }
      }

      // Assuming you want to fetch the latest order for a specific user or condition
      // Example: Fetching the latest order for the current user
      // Replace this logic with your own to determine which order to use
      String userPhoneNumber =
          UserData.getPhoneNumber(); // Adjust to your user identification logic
      if (latestOrdersMap.containsKey(userPhoneNumber)) {
        DocumentSnapshot latestOrderSnapshot = latestOrdersMap[userPhoneNumber];
        _orderId =
            latestOrderSnapshot.id; // Set _orderId to the latest order ID
        print('Latest order ID fetched: $_orderId');

        // Now fetch service provider data for the latest order found
        bool serviceProviderFound =
            await _fetchServiceProviderForOrder(_orderId, userPhoneNumber);

        if (!serviceProviderFound) {
          print('No matching service provider found for the latest order');
          setState(() {
            _isWaiting = false;
            _serviceProviderData = null;
          });
          if (_updateBottomSheet != null) {
            _updateBottomSheet!(() {});
          }
        }
      } else {
        print('No latest order found for userPhoneNumber: $userPhoneNumber');
        setState(() {
          _isWaiting = false;
          _serviceProviderData = null;
        });
        if (_updateBottomSheet != null) {
          _updateBottomSheet!(() {});
        }
      }
    } catch (e) {
      print('Error fetching latest orders: $e');
      setState(() {
        _isWaiting = false;
        _serviceProviderData = null;
      });
    }
  }*/

  void _cancelOrder() {
    setState(() {
      _isWaiting = false;
      _serviceProviderData = null;
    });

    // Update order status to "canceled" in Realtime Database
    //_updateOrderStatusToCanceled();

    // Remove service provider information from history collection
    removeHistoryDocument();

    // Remove the order from Realtime Database
    _removeOrderFromRealtimeDatabase();
  }

  Future<void> _removeOrderFromRealtimeDatabase() async {
    try {
      if (_orderId.isNotEmpty) {
        DatabaseReference databaseReference =
            FirebaseDatabase.instance.reference();

        String path = 'orders/$_orderId';
        print('Removing order at path: $path'); // Log path for debugging

        // Attempt to remove the order from Realtime Database
        await databaseReference.child(path).remove();

        print('Order removed successfully from Realtime Database');
      } else {
        print('Error: _orderId is empty or null');
        // Handle the case where _orderId is empty or null
      }
    } catch (e) {
      print('Error removing order from Realtime Database: $e');
      // Log the actual error to understand the cause of the issue
    }
  }

  Future<void> removeHistoryDocument() async {
    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Query for the document to update based on user's phone number and orderId
      QuerySnapshot querySnapshot = await firestore
          .collection('HISTORY')
          .where('userPhoneNumber', isEqualTo: UserData.getPhoneNumber())
          .where('orderId', isEqualTo: _orderId)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        // Update the document in 'HISTORY' collection
        DocumentReference docRef = querySnapshot.docs.first.reference;
        await docRef.delete();

        print('Document deleted from HISTORY collection');
      } else {
        print('No document found in HISTORY collection to delete');
      }
    } catch (e) {
      print('Error deleting document from HISTORY collection: $e');
      // Handle error as needed
    }
  }

  void _showConfirmationBottomSheet() {
    bool hasNavigated =
        false; // Flag to check if navigation has already occurred

    showModalBottomSheet(
      context: context,
      isDismissible: false,
      builder: (BuildContext context) {
        int countdownSeconds = 10; // 5 minutes in seconds

        // Countdown timer widget
        Widget countdownWidget = StreamBuilder(
          stream: Stream.periodic(
              const Duration(seconds: 1), (i) => countdownSeconds - i - 1),
          builder: (BuildContext context, AsyncSnapshot<int> snapshot) {
            if (snapshot.hasData) {
              int seconds = snapshot.data!;
              if (seconds <= 0 && !hasNavigated) {
                // Timer reaches 0, navigate to CleaningPage and set the flag to true
                hasNavigated = true;

                WidgetsBinding.instance?.addPostFrameCallback((_) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CleaningPage(
                        isServiceProvider: false,
                        onToggleRole: () {},
                      ),
                    ),
                  );
                });

                return const Text(
                  'Service provider will arrive soon',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                  ),
                );
              }
              int minutes = seconds ~/ 60;
              int remainingSeconds = seconds % 60;
              return Text(
                'Service provider will arrive in $minutes:${remainingSeconds.toString().padLeft(2, '0')} minutes',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
              );
            } else {
              return const SizedBox.shrink();
            }
          },
        );

        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Container(
              padding: const EdgeInsets.all(16),
              height: MediaQuery.of(context).size.height * 0.4,
              width: 500,
              color: const Color(0xFF112D4E),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  countdownWidget,
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      _cancelOrder();
                      removeHistoryDocument(); // Call removeHistoryDocument when cancel button is pressed
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CleaningPage(
                            isServiceProvider: false,
                            onToggleRole: () {},
                          ),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: const Color(0xFF112D4E),
                      backgroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 10),
                      textStyle: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    child: const Text('Cancel Order'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> saveToHistoryCollection(
      Map<String, dynamic> serviceProviderData) async {
    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Generate a unique document ID
      String documentId = DateTime.now().millisecondsSinceEpoch.toString();

      // Get user's phone number
      String userPhoneNumber = UserData.getPhoneNumber();

      // Create a reference to the document in the 'HISTORY' collection
      DocumentReference historyDocRef =
          firestore.collection('HISTORY').doc(documentId);

      // Set document data
      await historyDocRef.set({
        'name': serviceProviderData['name'],
        'phoneNumber': serviceProviderData['phoneNumber'],
        'photoUrl': serviceProviderData['photoUrl'],
        'userPhoneNumber': userPhoneNumber,
        'timestamp': FieldValue.serverTimestamp(),
      });

      print('Service provider information saved to HISTORY collection');
    } catch (e) {
      print('Error saving to HISTORY collection: $e');
      // Handle error as needed
    }
  }

  Future<void> _fetchLatestOrderAndProvider() async {
    print('Fetching latest orders...');
    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Fetch all orders sorted by timestamp in descending order
      QuerySnapshot ordersSnapshot = await firestore
          .collection('orders')
          .orderBy('timestamp', descending: true)
          .get();

      if (ordersSnapshot.docs.isEmpty) {
        print('No orders found');
        setState(() {
          _isWaiting = false;
          _serviceProviderData = null;
        });
        if (_updateBottomSheet != null) {
          _updateBottomSheet!(() {});
        }
        return;
      }

      // Map to store the latest order for each phone number
      Map<String, dynamic> latestOrdersMap = {};

      // Iterate through each order to find the latest order for each phone number
      for (var orderDoc in ordersSnapshot.docs) {
        String phoneNumber = orderDoc['phoneNumber'];

        // Check if we already have the latest order for this phone number
        if (!latestOrdersMap.containsKey(phoneNumber)) {
          latestOrdersMap[phoneNumber] = orderDoc;
        }
      }

      // Now fetch service provider data for each latest order found
      bool serviceProviderFound = false;

      for (var entry in latestOrdersMap.entries) {
        String phoneNumber = entry.key;
        DocumentSnapshot orderSnapshot = entry.value;

        // Fetch service provider data for the latest order
        serviceProviderFound =
            await _fetchServiceProviderForOrder(orderSnapshot.id, phoneNumber);

        if (serviceProviderFound) {
          break; // Stop iterating if a service provider is found
        }
      }

      if (!serviceProviderFound) {
        print('No matching service provider found for any order');
      }
    } catch (e) {
      print('Error fetching latest orders: $e');
      setState(() {
        _isWaiting = false;
        _serviceProviderData = null;
      });
    }
  }

  Future<bool> _fetchServiceProviderForOrder(
      String orderId, String phoneNumber) async {
    print('Fetching service provider data for order ID: $orderId...');
    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Fetch the order details
      DocumentSnapshot orderSnapshot =
          await firestore.collection('orders').doc(orderId).get();

      if (!orderSnapshot.exists || orderSnapshot.data() == null) {
        print('Order document with $orderId does not exist or data is null');
        setState(() {
          _isWaiting = false;
          _serviceProviderData = null;
        });
        if (_updateBottomSheet != null) {
          _updateBottomSheet!(() {});
        }
        return false; // Return false if order document does not exist or data is null
      }

      Map<String, dynamic>? orderData =
          orderSnapshot.data() as Map<String, dynamic>?;

      print('Order data: $orderData');

      // Extract service types and preferred gender from order
      List<String> requestedServices = (orderData?['rooms'] as List<dynamic>)
          .map((room) => room['name'] as String)
          .toList();

      String? preferredGender = orderData?['preferredGender'];

      print('Requested services: $requestedServices');
      print('Preferred gender: $preferredGender');

      // Fetch service providers that match the preferred gender and offer the requested services
      QuerySnapshot serviceProviderSnapshot = await firestore
          .collection('serviceProviders')
          .where('gender', isEqualTo: preferredGender)
          .get();

      print('Service provider snapshot: ${serviceProviderSnapshot.docs}');

      List<Map<String, dynamic>> matchingProviders = [];

      for (var doc in serviceProviderSnapshot.docs) {
        Map<String, dynamic> serviceProviderData =
            doc.data() as Map<String, dynamic>;
        List<dynamic> serviceTypes = serviceProviderData['serviceTypes'];

        // Check if the service provider offers all requested services or more
        bool offersAllServices = requestedServices
            .every((service) => serviceTypes.contains(service));

        if (offersAllServices) {
          // Ensure the gender matches as well
          if (serviceProviderData['gender'] == preferredGender) {
            matchingProviders.add(serviceProviderData);
          }
        }
      }

      if (matchingProviders.isNotEmpty) {
        // Select the first matching service provider (you can implement your logic here to select based on preference)
        Map<String, dynamic> serviceProviderData = matchingProviders.first;

        setState(() {
          _isWaiting = false;
          _serviceProviderData = serviceProviderData;
        });

        if (_updateBottomSheet != null) {
          _updateBottomSheet!(() {});
        }

        return true; // Return true if a matching provider is found
      } else {
        print('No matching service provider found for order ID: $orderId');
        setState(() {
          _isWaiting = false;
          _serviceProviderData = null;
        });

        if (_updateBottomSheet != null) {
          _updateBottomSheet!(() {});
        }

        return false; // Return false if no matching provider is found
      }
    } catch (e) {
      print('Error fetching service provider data: $e');
      setState(() {
        _isWaiting = false;
        _serviceProviderData = null;
      });
      return false; // Return false in case of error
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: const MAP()),
    );
  }
}
