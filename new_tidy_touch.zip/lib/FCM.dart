/*import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void _sendNotificationToProvider(String providerId, String orderId) async {
  try {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    
    // Step 1: Retrieve provider's FCM token from Firestore
    DocumentSnapshot providerSnapshot = await firestore.collection('serviceProviders').doc(providerId).get();
    
    if (!providerSnapshot.exists || providerSnapshot.data() == null) {
      print('Provider document with ID $providerId does not exist or data is null');
      return;
    }
    
    String? fcmToken = providerSnapshot.data()?['fcmToken'];
    
    if (fcmToken == null) {
      print('Provider with ID $providerId does not have an FCM token');
      return;
    }
    
    // Step 2: Send a notification to that token indicating the order details
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    
    // Example notification payload (adjust according to your app's needs)
    var notification = {
      'notification': {
        'title': 'New Order Available',
        'body': 'You have a new order to review.',
      },
      'data': {
        'orderId': orderId,
      },
      'token': fcmToken,
    };
    
    // Send the notification
    await messaging.send(notification);
    
    print('Notification sent successfully to provider with ID $providerId');
  } catch (e) {
    print('Error sending notification to provider: $e');
  }
}*/
