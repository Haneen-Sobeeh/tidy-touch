class Order {
  String day;
  double value;
  String _serviceProvider; // Private variable for service provider
  String contactNumber;
  String image;

  Order({
    required this.day,
    required this.value,
    required String name,
    required this.contactNumber,
    required this.image,
  }) : _serviceProvider = name;

  String get serviceProvider => _serviceProvider; // Getter for service provider

  set serviceProvider(String name) {
    _serviceProvider = name; // Setter for service provider
  }
}
