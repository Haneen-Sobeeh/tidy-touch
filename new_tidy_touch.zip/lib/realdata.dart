//FirebaseApp secondaryApp = Firebase.app('SecondaryApp');
//FirebaseDatabase database = FirebaseDatabase.instanceFor(app: secondaryApp);
/*
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'ConnectWithUsPage.dart';
import 'HistoryOrdersPage.dart';
import 'ProfileSettingsPage.dart';
import 'afterOrder.dart';
import 'login_page.dart'; // Ensure you have these imports

class CleaningPage extends StatefulWidget {
  final bool isServiceProvider;
  final VoidCallback onToggleRole;

  const CleaningPage({
    Key? key,
    required this.isServiceProvider,
    required this.onToggleRole,
  }) : super(key: key);

  @override
  _CleaningPageState createState() => _CleaningPageState();
}

class _CleaningPageState extends State<CleaningPage> {
  // Initialize FirebaseAuth instance
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Method to get current user
  Future<User?> getUser() async {
    return _auth.currentUser;
  }

  // Method to sign out
  Future<void> signOut() async {
    await _auth.signOut();
  }

  ValueNotifier<int> _gardenSizeNotifier = ValueNotifier<int>(10);
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  bool _isHovering = false;
  String _userPhoneNumber = UserData.getPhoneNumber();
  // Placeholder, replace with actual login logic

  List<List<dynamic>> _rooms = [
    [
      'Room',
      'https://img.icons8.com/officel/2x/living-room.png',
      Colors.red,
      1
    ],
    [
      'Bedroom',
      'https://img.icons8.com/fluency/2x/bedroom.png',
      Colors.orange,
      1
    ],
    ['Bathroom', 'https://img.icons8.com/color/2x/bath.png', Colors.blue, 1],
    [
      'Outdoor Stairs',
      'https://img.icons8.com/?size=256&id=DqvMP11bdFqX&format=png',
      Colors.green,
      1
    ],
    [
      'House Garden',
      'https://img.icons8.com/?size=80&id=rMYPr6ODJKc5&format=png',
      Colors.yellow,
      0
    ]
  ];

  List<String> _kitchenOptions = [
    'Small',
    'Medium',
    'Large',
  ];

  List<int> _selectedRooms = [];
  Map<String, dynamic> _roomQuantities = {};

  // Gender selection variables
  int? _selectedGender; // 0 for Male, 1 for Female
  List<String> _genders = ['Male', 'Female'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Positioned(
            top: 30.0,
            left: 10.0,
            child: MouseRegion(
              cursor: SystemMouseCursors.click,
              onEnter: (_) => setState(() => _isHovering = true),
              onExit: (_) => setState(() => _isHovering = false),
              child: IconButton(
                icon: Icon(
                  Icons.menu,
                  color: _isHovering ? Color(0xFF112D4E) : Color(0xFF112D4E),
                ),
                onPressed: () {
                  _scaffoldKey.currentState?.openDrawer();
                },
                color: Colors.white,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      20.0, 50.0, 20.0, 10.0), // Increase the top padding
                  child: Text(
                    'Please select the part/s of your house you want to be cleaned:',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: ListView.builder(
                    itemCount: _rooms.length +
                        2, // Including kitchen and gender selection as separate items
                    itemBuilder: (BuildContext context, int index) {
                      if (index == _rooms.length) {
                        return kitchenWidget();
                      } else if (index == _rooms.length + 1) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            SizedBox(height: 20),
                            Text(
                              'Preferred Gender of Cleaning Staff:',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Column(
                              children: _genders.asMap().entries.map((entry) {
                                int idx = entry.key;
                                String val = entry.value;
                                return RadioListTile(
                                  title: Text(val),
                                  value: idx,
                                  groupValue: _selectedGender,
                                  onChanged: (int? value) {
                                    setState(() {
                                      _selectedGender = value;
                                    });
                                  },
                                );
                              }).toList(),
                            ),
                          ],
                        );
                      }
                      return roomWidget(_rooms[index], index);
                    },
                  ),
                ),
                if (_selectedRooms.isNotEmpty)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 1),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: Offset(0, 3),
                        ),
                      ],
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(15),
                      child: Column(
                        children: [
                          Text(
                            'Expected Cost: ${calculateTotalCost()} JD',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Roboto',
                              shadows: [
                                Shadow(
                                  color: Colors.black.withOpacity(0.5),
                                  offset: Offset(0, 2),
                                  blurRadius: 4,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 10),
                          ElevatedButton(
                            onPressed: () async {
                              if (_selectedGender == null) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: Colors
                                        .red, // Set the background color to red
                                    content: Text(
                                      'Please select the preferred gender of the cleaning staff.',
                                      style: TextStyle(
                                          color: Colors
                                              .white), // Set text color to white
                                    ),
                                  ),
                                );
                                return; // Exit the onPressed callback if gender is not selected
                              }

                              // Save data to Firestore
                              saveOrderToFirestore();

                              // Navigate to AfterOrderPage after saving order
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => AfterOrderPage(),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFF112D4E),
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(
                                  horizontal: 30, vertical: 15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              textStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            child: Text('Order Now'),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          color: Color(0xFF112D4E),
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFF112D4E),
                ),
                child: Center(
                  child: Text(
                    'Settings',
                    style: TextStyle(
                      color: Color(0xFFDBE2EF),
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.person, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Profile Settings',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProfileSettingsPage(
                        isServiceProvider: false,
                        onToggleRole: () {},
                        showAvatar: false,
                      ),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.history, color: Color(0xFFDBE2EF)),
                title: Text(
                  'History Orders',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HistoryOrdersPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.contact_mail, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Contact With Us',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ContactUsPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.logout, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Logout',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        backgroundColor: Color(0xFF3F72AF),
                        title: Text(
                          'Confirm Logout',
                          style: TextStyle(color: Color(0xFFDBE2EF)),
                        ),
                        content: Text(
                          'Are you sure you want to log out?',
                          style: TextStyle(color: Color(0xFFDBE2EF)),
                        ),
                        actions: <Widget>[
                          TextButton(
                            child: Text(
                              'Cancel',
                              style: TextStyle(color: Color(0xFFDBE2EF)),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          TextButton(
                            child: Text(
                              'Logout',
                              style: TextStyle(color: Color(0xFFDBE2EF)),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => LoginPage(),
                                ),
                              );
                            },
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget roomWidget(List<dynamic> room, int index) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 5.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: _selectedRooms.contains(index)
              ? room[2].withOpacity(0.3)
              : Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: ListTile(
          onTap: () {
            setState(() {
              if (_selectedRooms.contains(index)) {
                _selectedRooms.remove(index);
                if (room[0] == 'House Garden') {
                  _roomQuantities.remove('House Garden');
                  _gardenSizeNotifier.value =
                      10; // Reset garden size to default
                } else {
                  _roomQuantities.remove(room[0]);
                }
              } else {
                _selectedRooms.add(index);
                if (room[0] == 'House Garden') {
                  _roomQuantities['House Garden'] = 1;
                  _gardenSizeNotifier.value =
                      10; // Set default garden size to 10m²
                } else {
                  _roomQuantities[room[0]] = room[3];
                }
              }
            });
          },
          leading: Image.network(
            room[1],
            height: 40,
            width: 40,
          ),
          title: Text(
            room[0],
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          trailing: _selectedRooms.contains(index)
              ? room[0] == 'House Garden'
                  ? ValueListenableBuilder<int>(
                      valueListenable: _gardenSizeNotifier,
                      builder: (context, gardenSize, child) {
                        return DropdownButton<int>(
                          value: gardenSize,
                          items: List.generate(
                            36,
                            (index) => DropdownMenuItem<int>(
                              value: (index + 1) * 10,
                              child: Text('${(index + 1) * 10} m²'),
                            ),
                          ),
                          onChanged: (int? newValue) {
                            if (newValue != null) {
                              _gardenSizeNotifier.value = newValue;
                              setState(() {}); // Trigger a state update
                            }
                          },
                        );
                      },
                    )
                  : Container(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.remove),
                            onPressed: () {
                              setState(() {
                                if (_roomQuantities[room[0]] > 1) {
                                  _roomQuantities[room[0]]--;
                                }
                              });
                            },
                          ),
                          Text(
                            '${_roomQuantities[room[0]]}',
                            style: TextStyle(fontSize: 18),
                          ),
                          IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () {
                              setState(() {
                                _roomQuantities[room[0]]++;
                              });
                            },
                          ),
                        ],
                      ),
                    )
              : null,
        ),
      ),
    );
  }

  Widget kitchenWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 5.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: _selectedRooms.contains(_rooms.length)
              ? Colors.purple.withOpacity(0.3)
              : Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: ListTile(
          onTap: () {
            setState(() {
              if (_selectedRooms.contains(_rooms.length)) {
                _selectedRooms.remove(_rooms.length);
                _roomQuantities.remove('Kitchen');
              } else {
                _selectedRooms.add(_rooms.length);
                _roomQuantities['Kitchen'] = 1;
              }
            });
          },
          leading: Image.network(
            'https://img.icons8.com/color/2x/kitchen-room.png',
            height: 40,
            width: 40,
          ),
          title: Text(
            'Kitchen',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          trailing: _selectedRooms.contains(_rooms.length)
              ? DropdownButton<String>(
                  value: _kitchenOptions[_roomQuantities['Kitchen'] - 1],
                  items: _kitchenOptions.map((String option) {
                    return DropdownMenuItem<String>(
                      value: option,
                      child: Text(option),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      _roomQuantities['Kitchen'] =
                          _kitchenOptions.indexOf(newValue!) + 1;
                    });
                  },
                )
              : null,
        ),
      ),
    );
  }

  Widget sizeOfGardenInput() {
    return ValueListenableBuilder<int>(
      valueListenable: _gardenSizeNotifier,
      builder: (context, value, child) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20.0),
            Text(
              "Select the size of the garden (in m²):",
              style: const TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 10.0),
            DropdownButton<int>(
              value: _gardenSizeNotifier.value,
              items: List.generate(
                  36,
                  (index) => DropdownMenuItem<int>(
                        value: index + 10,
                        child: Text('${index + 10} m²'),
                      )),
              onChanged: (int? newValue) {
                if (newValue != null) {
                  _gardenSizeNotifier.value = newValue;
                }
              },
            ),
          ],
        );
      },
    );
  }

  double calculateTotalCost() {
    double totalCost = 0;
    for (var entry in _roomQuantities.entries) {
      switch (entry.key) {
        case 'Room':
        case 'Bedroom':
          totalCost += entry.value * 5;
          break;
        case 'Bathroom':
          totalCost += entry.value * 7;
          break;
        case 'Kitchen':
          switch (_roomQuantities['Kitchen']) {
            case 1: // Small
              totalCost += entry.value * 7;
              break;
            case 2: // Medium
              totalCost += entry.value * 10;
              break;
            case 3: // Large
              totalCost += entry.value * 15;
              break;
          }
          break;
        case 'Outdoor Stairs':
          totalCost += entry.value * 10;
          break;
        case 'House Garden':
          int gardenSize = _gardenSizeNotifier.value ?? 0;
          totalCost += entry.value * (7 + (gardenSize ~/ 10) * 5);
          break;
      }
    }
    return totalCost;
  }

  void saveOrderToFirestore() async {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    FirebaseAuth auth = FirebaseAuth.instance;

    try {
      // Refresh the current user to ensure the latest profile information
      await auth.currentUser?.reload();
      User? user = auth.currentUser;

      if (user != null) {
        // User is signed in
        String? phoneNumber =
            user.phoneNumber; // Get phone number from authentication
        _userPhoneNumber =
            _userPhoneNumber; // Update _userPhoneNumber with the retrieved value

        // Create a new document in the "orders" collection
        DocumentReference orderRef = firestore.collection('orders').doc();

        // Prepare the order data
        Map<String, dynamic> orderData = {
          'phoneNumber': _userPhoneNumber, // Use the updated _userPhoneNumber
          'rooms': _selectedRooms.map((index) {
            if (index < _rooms.length) {
              return {
                'name': _rooms[index][0],
                'quantity': _roomQuantities[_rooms[index][0]],
              };
            } else {
              return {
                'name': 'Kitchen',
                'quantity': _roomQuantities['Kitchen'],
              };
            }
          }).toList(),
          'preferredGender':
              _selectedGender != null ? _genders[_selectedGender!] : null,
          'totalCost': calculateTotalCost(),
          'timestamp': FieldValue.serverTimestamp(),
        };

        // Save the order data to Firestore
        await orderRef.set(orderData);

        // Show a confirmation message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Order saved successfully!'),
          ),
        );
      } else {
        // No user is signed in
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('User not signed in.'),
          ),
        );
      }
    } catch (e) {
      // Handle errors
      print('Error saving order: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save order. Please try again later.'),
        ),
      );
    }
  }
}
*/
