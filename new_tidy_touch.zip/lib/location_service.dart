import 'package:location/location.dart';

class LocationService {
  final Location location = Location();

  Future<void> handleLocationAccess(String option) async {
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    switch (option) {
      case 'alwaysOn':
        // For Android, you might need to request the "Always On" permission
        // This is a simplified example, actual implementation may vary
        break;
      case 'onlyWhenUsingApp':
        // This is typically the default behavior
        break;
      case 'off':
        // Disable location access
        break;
      default:
        break;
    }
  }
}
