import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:myapp/service_provider_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ChangePhoneNumberPage.dart';
import 'change_password.dart';
import 'login_page.dart';
import 'new_password_page.dart';

class ProfileSettingsPage extends StatefulWidget {
  final bool isServiceProvider;
  final VoidCallback onToggleRole;
  final bool showAvatar;

  const ProfileSettingsPage({
    Key? key,
    required this.isServiceProvider,
    required this.onToggleRole,
    this.showAvatar = true,
  }) : super(key: key);

  @override
  _ProfileSettingsPageState createState() => _ProfileSettingsPageState();
}

class _ProfileSettingsPageState extends State<ProfileSettingsPage> {
  Uint8List? photoData;
  String _userPhoneNumber = UserData.getPhoneNumber();
  String? _documentId;

  @override
  void initState() {
    // Output the phone number for debugging
  }

  void _getImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? galleryImage =
        await picker.pickImage(source: ImageSource.gallery);

    if (galleryImage != null) {
      final Uint8List byteData = await galleryImage.readAsBytes();
      final String? downloadURL = await uploadPhoto(byteData);

      if (downloadURL != null) {
        await FirebaseFirestore.instance
            .collection(
                'serviceProviders') // or 'customers' based on your context
            .doc(_documentId)
            .update({'photoURL': downloadURL});

        setState(() {
          photoData = byteData;
        });
      }
    }
  }

  Future<String?> uploadPhoto(Uint8List byteData) async {
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_photos/${_documentId}.jpg');
      final uploadTask = storageRef.putData(byteData);
      final snapshot = await uploadTask.whenComplete(() {});
      final downloadURL = await snapshot.ref.getDownloadURL();
      return downloadURL;
    } catch (e) {
      print('Error uploading photo: $e');
      return null;
    }
  }

  void _deleteImage() async {
    try {
      await FirebaseFirestore.instance
          .collection(
              'serviceProviders') // or 'customers' based on your context
          .doc(_documentId)
          .update({'photoURL': FieldValue.delete()});

      setState(() {
        photoData = null;
      });
    } catch (e) {
      print('Error deleting photo URL: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: 30.0,
              left: 10.0,
              child: IconButton(
                icon: Icon(Icons.arrow_back, color: Color(0xFF112D4E)),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.showAvatar) ...[
                    GestureDetector(
                      onTap: _getImage,
                      child: CircleAvatar(
                        radius: 60,
                        backgroundImage:
                            photoData != null ? MemoryImage(photoData!) : null,
                        child: photoData == null
                            ? Icon(Icons.person, size: 36)
                            : null,
                      ),
                    ),
                    SizedBox(height: 20),
                    if (photoData != null) ...[
                      ElevatedButton.icon(
                        onPressed: _deleteImage,
                        icon: Icon(Icons.delete, size: 24),
                        label: Text('Delete Photo'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFF112D4E),
                          foregroundColor: Color(0xFFDBE2EF),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          minimumSize: Size(120, 36), // Adjust width here
                        ),
                      ),
                      SizedBox(height: 40), // Space after delete button
                    ],
                  ],
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ChangePhoneNumberPage(),
                        ),
                      );
                    },
                    icon: Icon(Icons.phone),
                    label: Text(
                      'Modify Phone Number',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF112D4E),
                      foregroundColor: Color(0xFFDBE2EF),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 14,
                      ),
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ChangePasswordPage(),
                        ),
                      );
                    },
                    icon: Icon(Icons.phone),
                    label: Text(
                      'Change Password',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF112D4E),
                      foregroundColor: Color(0xFFDBE2EF),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 14,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text(
                              'Confirm Delete',
                              style: TextStyle(color: Color(0xFF112D4E)),
                            ),
                            content: Text(
                              'Are you sure you want to delete your account?',
                              style: TextStyle(color: Color(0xFF112D4E)),
                            ),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context)
                                      .pop(); // Close the dialog
                                },
                                child: Text(
                                  'Cancel',
                                  style: TextStyle(color: Color(0xFF3F72AF)),
                                ),
                              ),
                              TextButton(
                                onPressed: () {
                                  /*String collectionType =
                                      'customers'; // or 'serviceProviders'
                                  _deleteAccount(
                                      collectionType); // Pass the collection type*/

                                  // Determine the user type dynamically
                                  bool userIsServiceProvider =
                                      true; // Replace this with your logic to determine user type
                                  String collectionType = userIsServiceProvider
                                      ? 'serviceProviders'
                                      : 'customers';

                                  _deleteAccount(
                                      collectionType); // Pass the collection type
                                },
                                child: Text(
                                  'Delete',
                                  style: TextStyle(color: Colors.red),
                                ),
                              ),
                            ],
                            backgroundColor: Color(0xFFDBE2EF),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                          );
                        },
                      );
                    },
                    icon: Icon(Icons.delete),
                    label: Text(
                      'Delete Account',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF112D4E),
                      foregroundColor: Color(0xFFDBE2EF),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      padding: EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 14,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /*void _deleteAccount(String collectionType) async {
    try {
      // Get the current user
      User? user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception('No user is signed in');
      }

      String userId = user.uid;

      // Delete the user's document from the specified collection
      await FirebaseFirestore.instance
          .collection(collectionType)
          .doc(userId)
          .delete();

      // Optionally, delete the user authentication account as well
      await user.delete();

      // Navigate to LoginPage
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
        (Route<dynamic> route) => false,
      );
    } catch (e) {
      // Handle errors (e.g., user not found, permissions issues)
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }*/

  void _deleteAccount(String collectionType) async {
    try {
      // Get the current user
      User? user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception('No user is signed in');
      }

      String userId = user.uid;
      String phoneNumber = _userPhoneNumber.trim(); // Ensure to trim whitespace

      // Query both collections to find the document with the matching phone number
      var serviceProviderQuery = await FirebaseFirestore.instance
          .collection('serviceProviders')
          .where('phoneNumber', isEqualTo: phoneNumber)
          .get();

      var customerQuery = await FirebaseFirestore.instance
          .collection('customers')
          .where('phone number', isEqualTo: phoneNumber)
          .get();

      // Check which collection contains the user document
      if (serviceProviderQuery.docs.isNotEmpty) {
        String docId = serviceProviderQuery.docs.first.id;
        await FirebaseFirestore.instance
            .collection('serviceProviders')
            .doc(docId)
            .delete();
        print('Document deleted from serviceProviders collection: $docId');
      } else if (customerQuery.docs.isNotEmpty) {
        String docId = customerQuery.docs.first.id;
        await FirebaseFirestore.instance
            .collection('customers')
            .doc(docId)
            .delete();
        print('Document deleted from customers collection: $docId');
      } else {
        throw Exception('User not found in any collection');
      }

      // Optionally, delete the user authentication account as well
      await user.delete();
      print('User authentication account deleted: $userId');

      // Navigate to LoginPage
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
        (Route<dynamic> route) => false,
      );
    } catch (e) {
      print('Error: ${e.toString()}'); // Log the error for debugging
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}
