import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:myapp/cleaning.dart'; // Ensure Firestore is imported

class Evaluation extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Main Screen')),
        body: Center(
          child: ElevatedButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    content: RatingDialogContent(),
                  );
                },
              );
            },
            child: Text('Open Evaluation'),
          ),
        ),
      ),
    );
  }
}

class RatingDialogContent extends StatefulWidget {
  @override
  _RatingDialogContentState createState() => _RatingDialogContentState();
}

class _RatingDialogContentState extends State<RatingDialogContent> {
  int _rating = 0;
  String serviceProviderName = "";
  String serviceProviderPhotoUrl = "";
  double serviceProviderPrice = 0.0;

  Future<void> fetchServiceProviderDetails() async {
    final FirebaseFirestore firestore = FirebaseFirestore.instance;
    final DocumentSnapshot documentSnapshot =
        await firestore.collection('serviceProviders').doc('providerId').get();

    if (documentSnapshot.exists) {
      setState(() {
        serviceProviderName = documentSnapshot['name'];
        serviceProviderPhotoUrl = documentSnapshot['photoUrl'];
        serviceProviderPrice = documentSnapshot['price'];
      });
    } else {
      // Handle case where document doesn't exist
    }
  }

  @override
  void initState() {
    super.initState();
    fetchServiceProviderDetails(); // Fetch details when the dialog initializes
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            IconButton(
              icon: Icon(Icons.close),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        ),
        // Service Provider Details Section
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(serviceProviderName,
                  style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              CircleAvatar(
                radius: 30,
                backgroundImage: NetworkImage(serviceProviderPhotoUrl),
              ),
              SizedBox(height: 4),
              Text(
                  "\$${serviceProviderPrice.toStringAsFixed(2)} Price"), // Display the price
            ],
          ),
        ),

        // Comment Field
        TextField(
          onChanged: (value) {
            // Handle comment change
          },
          decoration: InputDecoration(
            labelText: 'Write your comment',
            border: OutlineInputBorder(),
          ),
          style: TextStyle(fontSize: 18),
        ),
        SizedBox(height: 20),

        // Rating Stars
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(5, (index) {
            return IconButton(
              icon: Icon(
                index < _rating ? Icons.star : Icons.star_border,
                color: index < _rating ? Colors.yellow : Colors.grey,
                size: 40,
              ),
              onPressed: () {
                setState(() {
                  _rating = index + 1;
                });
              },
            );
          }),
        ),
        SizedBox(height: 20),

        // Submit Button
        ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CleaningPage(
                  isServiceProvider: true, // or false depending on your logic
                  onToggleRole: () {
                    // Define the logic for toggling the role here
                  },
                ),
              ),
            );
          },
          child: Text('Submit'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF112D4E),
            foregroundColor: Colors.white,
            fixedSize: Size(200, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
          ),
        ),
      ],
    );
  }
}
