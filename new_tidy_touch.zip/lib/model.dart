// user_model.dart

class UserModel {
  String name;
  String phoneNumber;
  String gender;
  DateTime? dateOfBirth;
  String password;
  String idNumber;
  String pdfUrl;
  List<String> serviceTypes;

  UserModel({
    required this.name,
    required this.phoneNumber,
    required this.gender,
    required this.password,
    required this.idNumber,
    required this.pdfUrl,
    required this.serviceTypes,
    this.dateOfBirth,
  });
}
