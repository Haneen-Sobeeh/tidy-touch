import 'package:flutter/material.dart';
import 'ConnectWithUsPage.dart';
import 'HistoryOrdersPage.dart';
import 'ProfileSettingsPage.dart';
import 'login_page.dart';
import 'map.dart';
import 'service_order.dart';

class StartAsSPPage extends StatefulWidget {
  @override
  _StartAsSPPageState createState() => _StartAsSPPageState();
}

class _StartAsSPPageState extends State<StartAsSPPage> {
  bool _notificationsEnabled = true; // Initialize notificationsEnabled state
  bool _isServiceActive = false; // To track if the service is active
  String _buttonText = 'Start Service';
  int _totalServicePrice = 0; // To store the total price of the service

  void _toggleNotifications(bool newValue) {
    setState(() {
      _notificationsEnabled = newValue;
    });

    String snackBarMessage;
    Color textColor;

    if (_notificationsEnabled) {
      snackBarMessage = "Requests are now active due to your activation mode.";
      textColor = Colors.green; // Change to green for active state
    } else {
      snackBarMessage =
          "Requests are now inactive due to your activation mode.";
      textColor = Colors.red; // Change to red for inactive state
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Container(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
            color: Colors.grey[300], // Background color for the SnackBar
          ),
          child: Text(snackBarMessage, style: TextStyle(color: textColor)),
        ),
        duration: Duration(seconds: 2),
      ),
    );
  }

  Future<void> _fetchTotalServicePrice() async {
    // Simulate fetching the total price from Firebase
    await Future.delayed(Duration(seconds: 1)); // Simulate network delay
    setState(() {
      _totalServicePrice = 10; // Mock total price
    });
  }

  void _onStartServiceButtonPressed() {
    setState(() {
      _isServiceActive = !_isServiceActive;
      _buttonText = _isServiceActive ? 'End Service' : 'Start Service';
      _notificationsEnabled =
          !_isServiceActive; // Disable switch when service starts
    });

    if (_isServiceActive) {
      print('Service started.');
    } else {
      _endService();
    }
  }

  void _endService() async {
    await _fetchTotalServicePrice();
    _showServiceEndDialog();
  }

  void _showServiceEndDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Service Ended',
              style: TextStyle(
                color: Color(0xFF112D4E),
                fontWeight: FontWeight.bold,
              )),
          content: Text(
            'The total price of the service is \$$_totalServicePrice.',
            style: TextStyle(
              color: Color(0xFF112D4E),
              fontSize: 16,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                setState(() {
                  _notificationsEnabled =
                      true; // Re-enable switch when service ends
                });
                Navigator.of(context).pop();
              },
              child: Text(
                'OK',
                style: TextStyle(
                  color: Color(0xFF112D4E),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          backgroundColor: Color(0xFFDBE2EF),
        );
      },
    );
  }

  void _navigateToServiceOrderPage() {
    if (_notificationsEnabled) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ServiceOrderPage(
            serviceProviderId: '',
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enable notifications to proceed.',
              style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF112D4E),
        leading: Builder(
          builder: (context) => IconButton(
            icon: Icon(Icons.menu),
            color: Color(0xFFDBE2EF),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Switch(
              value: _notificationsEnabled,
              onChanged: _isServiceActive ? null : _toggleNotifications,
              activeColor: Colors.green,
              inactiveThumbColor: Colors.red,
              activeTrackColor: Color(0xFFDBE2EF),
              inactiveTrackColor: Color(0xFFDBE2EF),
            ),
            Text(
              _notificationsEnabled ? 'Active' : 'Inactive',
              style: TextStyle(
                color: Color(0xFFDBE2EF),
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.settings, color: Color(0xFFDBE2EF)),
            onPressed: _navigateToServiceOrderPage,
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          color: Color(0xFF112D4E),
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFF112D4E),
                ),
                child: Center(
                  child: Text(
                    'Settings',
                    style: TextStyle(
                      color: Color(0xFFDBE2EF),
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.person, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Profile Settings',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  var user;
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProfileSettingsPage(
                        isServiceProvider: true,
                        onToggleRole: () {},
                        showAvatar: true,
                      ),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.history, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Orders History',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HistoryOrdersPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.contact_mail, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Contact Us',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ContactUsPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.logout, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Logout',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        backgroundColor: Color(0xFF3F72AF),
                        title: Text(
                          'Confirm Logout',
                          style: TextStyle(color: Color(0xFFDBE2EF)),
                        ),
                        content: Text(
                          'Are you sure you want to log out?',
                          style: TextStyle(color: Color(0xFFDBE2EF)),
                        ),
                        actions: <Widget>[
                          TextButton(
                            child: Text(
                              'Cancel',
                              style: TextStyle(color: Color(0xFFDBE2EF)),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          TextButton(
                            child: Text(
                              'Logout',
                              style: TextStyle(color: Color(0xFFDBE2EF)),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => LoginPage(),
                                ),
                              );
                            },
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          MAP(), // This places your map as the background
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              color: Colors.transparent,
              padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
              child: Center(
                child: ElevatedButton(
                  onPressed: _onStartServiceButtonPressed,
                  child: Text(_buttonText),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        _isServiceActive ? Colors.red : Colors.green,
                    foregroundColor: Color(0xFFDBE2EF),
                    padding: EdgeInsets.symmetric(
                        horizontal: 24, vertical: 16), // Adjust button padding
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
