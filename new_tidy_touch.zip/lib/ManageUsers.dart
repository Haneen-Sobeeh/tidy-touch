import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ManageUsers(),
    );
  }
}

class ManageUsers extends StatefulWidget {
  @override
  _ManageUsersState createState() => _ManageUsersState();
}

class _ManageUsersState extends State<ManageUsers> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFF9F7F7),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              SizedBox(height: 40),
              Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: FaIcon(FontAwesomeIcons.arrowLeft,
                        color: Color(0xFF112D4E), size: 24),
                  ),
                  SizedBox(width: 10),
                  Text(
                    'Manage Users',
                    style: GoogleFonts.ptSerif(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF112D4E),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 40),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: _firestore.collection('serviceProviders').snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }
                    if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}'));
                    }
                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(child: Text('No service providers found.'));
                    }

                    final serviceProviders = snapshot.data!.docs;
                    List<Widget> serviceProviderCards = [];
                    for (var provider in serviceProviders) {
                      final data = provider.data() as Map<String, dynamic>;
                      print('Provider Data: $data'); // Debugging: Log data
                      serviceProviderCards.add(
                        _buildServiceProviderCard(
                          context: context,
                          name: data['name'] ?? 'N/A',
                          phoneNumber: data['phoneNumber'] ?? 'N/A',
                          pdfUrl: data['pdfUrl'] ?? '',
                          onDownloadPdf: () async {
                            await downloadPdf(data['pdfUrl']);
                          },
                          onAccept: () async {
                            await acceptServiceProvider(provider.id);
                          },
                          onReject: () async {
                            await rejectServiceProvider(provider.id);
                          },
                        ),
                      );
                    }
                    return ListView(
                      children: serviceProviderCards,
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> downloadPdf(String pdfUrl) async {
    try {
      // Launch the PDF URL directly
      if (await canLaunch(pdfUrl)) {
        await launch(pdfUrl);
      } else {
        throw 'Could not launch $pdfUrl';
      }
    } catch (e) {
      print('Error downloading PDF: $e'); // Log the error
    }
  }

  Future<void> acceptServiceProvider(String documentId) async {
    try {
      await _firestore
          .collection('serviceProviders')
          .doc(documentId)
          .update({'status': 'accepted'});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Service provider accepted.')),
      );
    } catch (e) {
      print('Error accepting service provider: $e');
    }
  }

  Future<void> rejectServiceProvider(String documentId) async {
    try {
      await _firestore.collection('serviceProviders').doc(documentId).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Service provider rejected.')),
      );
    } catch (e) {
      print('Error rejecting service provider: $e');
    }
  }

  Widget _buildServiceProviderCard({
    required BuildContext context,
    required String name,
    required String phoneNumber,
    required String pdfUrl,
    required VoidCallback onDownloadPdf,
    required VoidCallback onAccept,
    required VoidCallback onReject,
  }) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      color: Colors.white,
      elevation: 5,
      shadowColor: Colors.grey.withOpacity(0.3),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Name: $name',
              style: GoogleFonts.ptSerif(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 5),
            Text(
              'Phone: $phoneNumber',
              style: GoogleFonts.ptSerif(
                fontSize: 18,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onDownloadPdf,
                    icon: FaIcon(FontAwesomeIcons.fileDownload,
                        color: Colors.white, size: 20),
                    label: Text('Download PDF'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      textStyle: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onAccept,
                    icon: FaIcon(FontAwesomeIcons.check,
                        color: Colors.white, size: 20),
                    label: Text('Accept'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      textStyle: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onReject,
                    icon: FaIcon(FontAwesomeIcons.times,
                        color: Colors.white, size: 20),
                    label: Text('Reject'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      textStyle: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

//code with API
/*
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http; // Import for HTTP requests

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ManageUsers(),
    );
  }
}

class ManageUsers extends StatefulWidget {
  @override
  _ManageUsersState createState() => _ManageUsersState();
}

class _ManageUsersState extends State<ManageUsers> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFF9F7F7),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              SizedBox(height: 40),
              Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: FaIcon(FontAwesomeIcons.arrowLeft,
                        color: Color(0xFF112D4E), size: 24),
                  ),
                  SizedBox(width: 10),
                  Text(
                    'Manage Users',
                    style: GoogleFonts.ptSerif(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF112D4E),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 40),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: _firestore.collection('serviceProviders').snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }
                    if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}'));
                    }
                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(child: Text('No service providers found.'));
                    }

                    final serviceProviders = snapshot.data!.docs;
                    List<Widget> serviceProviderCards = [];
                    for (var provider in serviceProviders) {
                      final data = provider.data() as Map<String, dynamic>;
                      final pdfUrl = data['pdfUrl'] ?? '';

                      serviceProviderCards.add(
                        _buildServiceProviderCard(
                          context: context,
                          name: data['name'] ?? 'N/A',
                          phoneNumber: data['phoneNumber'] ?? 'N/A',
                          pdfUrl: pdfUrl,
                          onDownloadPdf: () async {
                            await downloadPdf(pdfUrl);
                          },
                          onAccept: () async {
                            await acceptServiceProvider(provider.id, pdfUrl);
                          },
                          onReject: () async {
                            await rejectServiceProvider(provider.id);
                          },
                        ),
                      );

                      // Detect if the PDF was just uploaded and notify the admin
                      if (pdfUrl.isNotEmpty && !data.containsKey('notified')) {
                        // Call to send WhatsApp notification
                        _sendWhatsAppNotification(
                            data['name'] ?? 'Service Provider', pdfUrl);

                        // Update Firestore to indicate that the admin has been notified
                        _firestore
                            .collection('serviceProviders')
                            .doc(provider.id)
                            .update({'notified': true});
                      }
                    }
                    return ListView(
                      children: serviceProviderCards,
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> downloadPdf(String pdfUrl) async {
    try {
      // Launch the PDF URL directly
      if (await canLaunch(pdfUrl)) {
        await launch(pdfUrl);
      } else {
        throw 'Could not launch $pdfUrl';
      }
    } catch (e) {
      print('Error downloading PDF: $e'); // Log the error
    }
  }

  Future<void> acceptServiceProvider(String documentId, String pdfUrl) async {
    try {
      await _firestore
          .collection('serviceProviders')
          .doc(documentId)
          .update({'status': 'accepted'});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Service provider accepted.')),
      );
    } catch (e) {
      print('Error accepting service provider: $e');
    }
  }

  Future<void> rejectServiceProvider(String documentId) async {
    try {
      await _firestore.collection('serviceProviders').doc(documentId).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Service provider rejected.')),
      );
    } catch (e) {
      print('Error rejecting service provider: $e');
    }
  }

  // Function to send WhatsApp notification using CallMeBot API
  Future<void> _sendWhatsAppNotification(String name, String pdfUrl) async {
    const String adminPhoneNumber =
        "+962786784596"; // Replace with actual WhatsApp number
    const String apiKey = "9538302"; // Replace with your API key
    final String message = "New PDF uploaded by $name. View it here: $pdfUrl";

    final String url =
        "https://api.callmebot.com/whatsapp.php?phone=$adminPhoneNumber&text=$message&apikey=$apiKey";

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        print('WhatsApp notification sent successfully.');
      } else {
        print('Failed to send WhatsApp notification.');
      }
    } catch (e) {
      print('Error sending WhatsApp notification: $e');
    }
  }

  Widget _buildServiceProviderCard({
    required BuildContext context,
    required String name,
    required String phoneNumber,
    required String pdfUrl,
    required VoidCallback onDownloadPdf,
    required VoidCallback onAccept,
    required VoidCallback onReject,
  }) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      color: Colors.white,
      elevation: 5,
      shadowColor: Colors.grey.withOpacity(0.3),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Name: $name',
              style: GoogleFonts.ptSerif(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 5),
            Text(
              'Phone: $phoneNumber',
              style: GoogleFonts.ptSerif(
                fontSize: 18,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onDownloadPdf,
                    icon: FaIcon(FontAwesomeIcons.fileDownload,
                        color: Colors.white, size: 20),
                    label: Text('Download PDF'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      textStyle: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onAccept,
                    icon: FaIcon(FontAwesomeIcons.check,
                        color: Colors.white, size: 20),
                    label: Text('Accept'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      textStyle: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onReject,
                    icon: FaIcon(FontAwesomeIcons.times,
                        color: Colors.white, size: 20),
                    label: Text('Reject'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      textStyle: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
*/
