import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'ManageUsers.dart';
import 'login_page.dart';
import 'view_reports.dart';
import 'block_user.dart';

class Admin extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFF9F7F7),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Welcome',
                style: GoogleFonts.ptSerif(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF112D4E),
                ),
              ),
              SizedBox(height: 40),
              _buildIconButton(
                context: context,
                icon: FontAwesomeIcons.users,
                label: 'Manage Users',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ManageUsers()),
                  );
                },
              ),
              SizedBox(height: 20),
              _buildIconButton(
                context: context,
                icon: FontAwesomeIcons.comments,
                label: 'User Feedback',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ViewReports()),
                  );
                },
              ),
              SizedBox(height: 20),
              _buildIconButton(
                context: context,
                icon: FontAwesomeIcons.userSlash,
                label: 'Block User',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => BlockUser()),
                  );
                },
              ),
              SizedBox(height: 40),
              _buildLogoutButton(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton({
    required BuildContext context,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Color(0xFFDBE2EF),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF112D4E).withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        padding: EdgeInsets.all(20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Icon(icon, size: 40, color: Color(0xFF112D4E)),
            SizedBox(width: 20),
            Text(
              label,
              style: GoogleFonts.ptSerif(
                fontSize: 20,
                color: Color(0xFF112D4E),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context) {
    return TextButton(
      onPressed: () {
        // Action for logging out
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      },
      child: Text('Logout', style: TextStyle(color: Colors.red, fontSize: 20)),
      style: TextButton.styleFrom(
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
        backgroundColor: Color(0xFFDBE2EF),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }
}
