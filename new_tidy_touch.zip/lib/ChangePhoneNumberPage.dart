import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login_page.dart';
import 'new_password_page.dart'; // Import the NewPasswordPage

class ChangePhoneNumberPage extends StatefulWidget {
  @override
  _ChangePhoneNumberPageState createState() => _ChangePhoneNumberPageState();
}

class _ChangePhoneNumberPageState extends State<ChangePhoneNumberPage> {
  final _formKey = GlobalKey<FormState>();
  String _oldPhoneNumber = '';
  String _newPhoneNumber = '';
  bool _isSaving = false;
  String _userPhoneNumber = UserData.getPhoneNumber();

  void _savePhoneNumber() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      if (_oldPhoneNumber == _newPhoneNumber) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content:
                Text('New phone number must be different from the old one'),
          ),
        );
        return;
      }

      if (_oldPhoneNumber != _userPhoneNumber) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
                'You are not allowed to change phone number. Please login first.'),
          ),
        );
        return;
      }

      setState(() {
        _isSaving = true;
      });

      try {
        // Check if new phone number already exists in customers collection
        var customerSnapshot = await FirebaseFirestore.instance
            .collection('customers')
            .where('phone number', isEqualTo: _newPhoneNumber)
            .get();
        if (customerSnapshot.docs.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                  'Phone number $_newPhoneNumber is already registered as a customer'),
            ),
          );
          setState(() {
            _isSaving = false;
          });
          return;
        }

        // Check if new phone number already exists in serviceProviders collection
        var serviceProviderSnapshot = await FirebaseFirestore.instance
            .collection('serviceProviders')
            .where('phoneNumber', isEqualTo: _newPhoneNumber)
            .get();
        if (serviceProviderSnapshot.docs.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                  'Phone number $_newPhoneNumber is already registered as a service provider'),
            ),
          );
          setState(() {
            _isSaving = false;
          });
          return;
        }

        // Update phone number in serviceProviders collection
        await _updatePhoneNumberInServiceProviders();

        // Update phone number in customers collection
        await _updatePhoneNumberInCustomers();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Phone number changed successfully')),
        );
      } catch (e) {
        print('Error updating phone number: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update phone number')),
        );
      }

      setState(() {
        _isSaving = false;
      });
    }
  }

  Future<void> _updatePhoneNumberInServiceProviders() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('serviceProviders')
        .where('phoneNumber', isEqualTo: _userPhoneNumber)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final doc = querySnapshot.docs.first;
      final docId = doc.id;

      await FirebaseFirestore.instance
          .collection('serviceProviders')
          .doc(docId)
          .update({'phoneNumber': _newPhoneNumber});
    }
  }

  Future<void> _updatePhoneNumberInCustomers() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('customers')
        .where('phone number', isEqualTo: _userPhoneNumber)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final doc = querySnapshot.docs.first;
      final docId = doc.id;

      await FirebaseFirestore.instance
          .collection('customers')
          .doc(docId)
          .update({'phone number': _newPhoneNumber});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Container(
              color: Color(0xFFF9F7F7),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      SizedBox(height: 80),
                      Text(
                        'Change Phone Number:',
                        style: GoogleFonts.ptSerif(
                            fontSize: 26, fontWeight: FontWeight.w700),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Enter Your Old and New Phone Numbers',
                        style: TextStyle(fontSize: 15),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(height: 20),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Color(0xFFDBE2EF),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          initialValue: _oldPhoneNumber,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'Old Phone Number',
                            labelStyle: TextStyle(color: Color(0xFF112D4E)),
                            prefixStyle: TextStyle(color: Color(0xFF112D4E)),
                            prefixIcon:
                                Icon(Icons.phone, color: Color(0xFF112D4E)),
                            border: InputBorder.none,
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            if (value.length != 10) {
                              return 'Phone number must be exactly 10 digits';
                            }
                            if (!value.startsWith('078') &&
                                !value.startsWith('079') &&
                                !value.startsWith('077')) {
                              return 'Phone number must start with 078, 079, or 077';
                            }
                            return null;
                          },
                          maxLength: 10,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(10),
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          onSaved: (value) => _oldPhoneNumber = value!,
                        ),
                      ),
                      SizedBox(height: 20),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Color(0xFFDBE2EF),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF112D4E).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          initialValue: _newPhoneNumber,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'New Phone Number',
                            labelStyle: TextStyle(color: Color(0xFF112D4E)),
                            prefixStyle: TextStyle(color: Color(0xFF112D4E)),
                            prefixIcon:
                                Icon(Icons.phone, color: Color(0xFF112D4E)),
                            border: InputBorder.none,
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            if (value.length != 10) {
                              return 'Phone number must be exactly 10 digits';
                            }
                            if (!value.startsWith('078') &&
                                !value.startsWith('079') &&
                                !value.startsWith('077')) {
                              return 'Phone number must start with 078, 079, or 077';
                            }
                            return null;
                          },
                          maxLength: 10,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(10),
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          onSaved: (value) => _newPhoneNumber = value!,
                        ),
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _isSaving ? null : _savePhoneNumber,
                        child: _isSaving
                            ? SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.white),
                                ),
                              )
                            : Text('Save'),
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          backgroundColor: Color(0xFF112D4E),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                          textStyle: GoogleFonts.ptSerif(
                              color: Colors.white, fontSize: 25),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 30.0,
            left: 10.0,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Color(0xFF112D4E)),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }
}
