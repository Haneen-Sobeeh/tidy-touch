import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:myapp/service_provider_page.dart';
import 'package:myapp/forgot_password_page.dart';
import 'package:myapp/role_selection_page.dart';
import 'package:provider/provider.dart';
import 'admin.dart';
import 'cleaning.dart';
import 'create_account_page_cutomer.dart';

class UserData {
  static String _email = '';

  static String getPhoneNumber() {
    return _email;
  }

  static void setPhoneNumber(String phoneNumber) {
    _email = phoneNumber;
    print('Phone number set to: $_email');
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';

  static const adminPhoneNumber = '0783456789';
  static const adminPassword = 'pass';

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  late AnimationController _animationController;
  late Animation<double> _logoAnimation;
  late Animation<double> _formAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(seconds: 1),
      vsync: this,
    )..forward();

    _logoAnimation = Tween<double>(begin: 0.5, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _formAnimation = Tween<double>(begin: 0.5, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOut,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Color with Gradient
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color.fromARGB(255, 255, 255, 255),
                    const Color.fromARGB(255, 255, 255, 255)
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          // Custom Wave Clipper for Top
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: ClipPath(
              clipper: WaveClipperOne(),
              child: Container(
                height: 250,
                color: Color(0xFF5483b3), // Updated lighter color
                child: Center(
                  child: FadeTransition(
                    opacity: _logoAnimation,
                    child: Image.asset(
                      'assets/photo_2024-03-14_17-19-56-removebg.png',
                      height: 150, // Increased logo size
                    ),
                  ),
                ),
              ),
            ),
          ),
          // Custom Wave Clipper for Bottom
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: ClipPath(
              clipper: WaveClipperTwo(),
              child: Container(
                height: 100,
                color: const Color.fromARGB(255, 255, 255, 255),
              ),
            ),
          ),
          // Main Content
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                      height:
                          10), // Reduced space above "Please login to continue"
                  Text(
                    'Please login to continue',
                    style: GoogleFonts.lora(
                        fontSize: 16, color: Color(0xff293c45)), // Darker grey
                  ),
                  SizedBox(height: 20), // Adjusted space before form
                  FadeTransition(
                    opacity: _formAnimation,
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: <Widget>[
                            _buildTextField(
                              labelText: 'Email',
                              icon: Icons.phone,
                              onSaved: (value) => _email = value!,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your Email';
                                }
                                // if (value.length != 100) {
                                //  return 'Email must be exactly 100 digits';
                                //  }
                                /* if (!value.startsWith('078') &&
                                   // !value.startsWith('079') &&
                                   // !value.startsWith('077')) {
                                  return 'Phone number must start with 078, 079, or 077';
                                }*/
                                return null;
                              },
                              // maxLength: 100,
                              // inputFormatter:
                              // FilteringTextInputFormatter.digitsOnly,
                            ),
                            SizedBox(
                                height:
                                    10), // Reduced space between phone number and password fields
                            _buildTextField(
                              labelText: 'Password',
                              icon: Icons.lock,
                              obscureText: true,
                              onSaved: (value) => _password = value!,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your password';
                                }
                                return null;
                              },
                            ),
                            SizedBox(
                                height:
                                    20), // Adjusted space before login button
                            _buildElevatedButton(
                              onPressed: () async {
                                if (_formKey.currentState!.validate()) {
                                  _formKey.currentState!.save();
                                  try {
                                    await _signInUser();
                                  } catch (e) {
                                    print('Error during sign in: $e');
                                    _showErrorDialog(
                                        'An error occurred during sign in');
                                  }
                                }
                              },
                              text: 'Login',
                              icon: Icons.login,
                            ),
                            SizedBox(
                                height:
                                    10), // Reduced space between login button and forgot password link
                            _buildTextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ForgotPasswordPage()),
                                );
                              },
                              text: 'Forgot Password?',
                            ),
                            SizedBox(
                                height:
                                    10), // Reduced space between login button and forgot password link
                            _buildTextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => CleaningPage(
                                      isServiceProvider:
                                          true, // Adjust as needed
                                      onToggleRole: () {},
                                    ),
                                  ),
                                );
                              },
                              text: 'join as a guest',
                            ),
                            SizedBox(height: 5), // Decreased spacing
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("Don't have an account? "),
                                _buildTextButton(
                                  onPressed: () {
                                    Provider.of<RoleProvider>(context,
                                            listen: false)
                                        .setRole('Customer');

                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CreateAccountPageCustomer()),
                                    );
                                  },
                                  text: 'Sign Up',
                                ),
                              ],
                            ),
                            SizedBox(
                                height: 7), // Spacing between the two options
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                _buildTextButton(
                                  onPressed: () {
                                    Provider.of<RoleProvider>(context,
                                            listen: false)
                                        .setRole('Service Provider');
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ServiceProviderPage()),
                                    );
                                  },
                                  text: 'Join Us',
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required String labelText,
    required IconData icon,
    bool obscureText = false,
    required Function(String?) onSaved,
    required String? Function(String?) validator,
    String? prefixText,
    int? maxLength,
    TextInputFormatter? inputFormatter,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      padding: const EdgeInsets.all(4.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: TextFormField(
        obscureText: obscureText,
        decoration: InputDecoration(
          labelText: labelText,
          labelStyle: TextStyle(color: Colors.blueGrey.shade600),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide.none,
          ),
          prefixIcon: Icon(icon, color: Colors.blue.shade700), // Darker blue
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        ),
        validator: validator,
        onSaved: onSaved,
        inputFormatters: [
          if (maxLength != null) LengthLimitingTextInputFormatter(maxLength),
          if (inputFormatter != null) inputFormatter,
        ],
      ),
    );
  }

  Widget _buildElevatedButton({
    required VoidCallback onPressed,
    required String text,
    required IconData icon,
  }) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, color: Colors.white),
      label: Text(
        text,
        style: GoogleFonts.ptSerif(color: Colors.white, fontSize: 18),
      ),
      style: ElevatedButton.styleFrom(
        fixedSize: Size(250, 60),
        padding: EdgeInsets.symmetric(vertical: 15),
        backgroundColor: Color(0xFF5483b3), // Darker blue
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        elevation: 5,
      ),
    );
  }

  Widget _buildTextButton({
    required VoidCallback onPressed,
    required String text,
  }) {
    return TextButton(
      onPressed: onPressed,
      child: Text(
        text,
        style:
            TextStyle(color: Colors.blue.shade700, fontSize: 16), // Darker blue
      ),
      style: TextButton.styleFrom(
        padding: EdgeInsets.zero,
        textStyle:
            TextStyle(decoration: TextDecoration.none), // Remove underline
      ),
    );
  }

  /* void _signIn() async {
    if (_email == adminPhoneNumber && _password == adminPassword) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => Admin()),
      );
    } else {
      try {
        UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: 'user@example.com',
          password: _password,
        );

        User? user = userCredential.user;
        if (user != null) {
          // Retrieve the user role from Firestore
          DocumentSnapshot userDoc =
              await _firestore.collection('users').doc(user.uid).get();
          String userRole = userDoc['role'];

          // Navigate based on user role
          if (userRole == 'service_provider') {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => ServiceProviderPage()),
            );
          } else if (userRole == 'customer') {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => CleaningPage(
                        isServiceProvider: false,
                        onToggleRole: () {},
                      )),
            );
          }
        }
      } catch (e) {
        print('Error signing in: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Sign in failed. Please check your credentials.'),
          ),
        );
      }
    }
  }*/

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _signInUser() async {
    print('Trying to sign in...');
    try {
      // Attempt to sign in with email and password
      final UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email,
        password: _password,
      );

      User? user = userCredential.user;
      if (user != null) {
        // Successfully signed in
        print('User signed in: ${user.uid}');

        // Update password in Firebase Authentication
        await user.updatePassword(_password);

        // Update password in Firestore
        await _updatePasswordInFirestore(user.uid);

        // Update password in Realtime Database
        await _updatePasswordInRealtimeDatabase(user.uid);

        // Navigate to the CleaningPage if sign-in is successful
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CleaningPage(
              isServiceProvider: true, // Adjust as needed
              onToggleRole: () {},
            ),
          ),
        );
      } else {
        // Handle the case where user is null
        _showErrorDialog(
            'Failed to sign in. Please check your email and password.');
      }
    } catch (e) {
      print('An unexpected error occurred during sign in: $e');
      _showErrorDialog('An unexpected error occurred during sign in: $e');
    }
  }

  Future<void> _updatePasswordInRealtimeDatabase(String uid) async {
    try {
      final ref = _database.ref();

      // Check if user exists in customers collection
      DataSnapshot customerSnapshot =
          await ref.child('customers').child(uid).get();
      if (customerSnapshot.exists) {
        await ref.child('customers').child(uid).update({
          'password': _password,
        });
        print('Updated password for customer');
      }
      // If not a customer, assume it's a service provider
      else {
        await ref.child('serviceProviders').child(uid).update({
          'password': _password,
        });
        print('Updated password for service provider');
      }
    } catch (e) {
      print('Error updating password in Realtime Database: $e');
      _showErrorDialog('Failed to update password in Realtime Database');
    }
  }

  Future<void> _updatePasswordInFirestore(String uid) async {
    try {
      // Get the user document from Firestore
      DocumentSnapshot userDoc =
          await _firestore.collection('users').doc(uid).get();

      if (userDoc.exists) {
        String userRole = userDoc.get('role');

        // Update password in the appropriate collection
        if (userRole == 'service_provider') {
          await _firestore.collection('serviceProviders').doc(uid).update({
            'password': _password,
          });
          print('Updated password for service provider in Firestore');
        } else if (userRole == 'customer') {
          await _firestore.collection('customers').doc(uid).update({
            'password': _password,
          });
          print('Updated password for customer in Firestore');
        } else {
          print('Unknown user role');
        }
      } else {
        print('User document not found in Firestore');
      }
    } catch (e) {
      print('Error updating password in Firestore: $e');
      _showErrorDialog('Failed to update password in Firestore');
    }
  }
}

class RoleProvider extends ChangeNotifier {
  String _role = '';

  String get role => _role;

  void setRole(String role) {
    _role = role;
    notifyListeners();
  }
}
