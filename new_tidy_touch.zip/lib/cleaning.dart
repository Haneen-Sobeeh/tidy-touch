import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'ConnectWithUsPage.dart';
import 'HistoryOrdersPage.dart';
import 'ProfileSettingsPage.dart';
import 'afterOrder.dart';
import 'login_page.dart'; // Ensure you have these imports
import 'package:firebase_database/firebase_database.dart';

class CleaningPage extends StatefulWidget {
  final bool isServiceProvider;
  final VoidCallback onToggleRole;

  const CleaningPage({
    Key? key,
    required this.isServiceProvider,
    required this.onToggleRole,
  }) : super(key: key);

  @override
  _CleaningPageState createState() => _CleaningPageState();
}

class _CleaningPageState extends State<CleaningPage> {
  // Initialize FirebaseAuth instance
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  String stateus = '';

  @override
  void initState() {
    super.initState();
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      if (user == null) {
        print('User is currently signed out!');
      } else {
        print('User is signed in! UID: ${user.uid}');
      }
    });
  }

  // Method to get current user
  Future<User?> getUser() async {
    return _auth.currentUser;
  }

  // Method to sign out
  void logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      print('User logged out successfully');
    } catch (e) {
      print('Error during logout: $e');
    }
  }

  ValueNotifier<int> _gardenSizeNotifier = ValueNotifier<int>(10);
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  bool _isHovering = false;
  String _userPhoneNumber = UserData.getPhoneNumber();
  // Placeholder, replace with actual login logic

  List<List<dynamic>> _rooms = [
    [
      'Room',
      'https://img.icons8.com/officel/2x/living-room.png',
      Colors.red,
      1
    ],
    [
      'Bedroom',
      'https://cdn-icons-png.flaticon.com/512/2642/2642358.png',
      const Color.fromARGB(255, 222, 191, 144),
      1
    ],
    ['Bathroom', 'https://img.icons8.com/color/2x/bath.png', Colors.blue, 1],
    [
      'Outdoor Stairs',
      'https://img.icons8.com/?size=256&id=DqvMP11bdFqX&format=png',
      Colors.green,
      1
    ],
    [
      'House Garden',
      'https://img.icons8.com/?size=80&id=rMYPr6ODJKc5&format=png',
      Colors.yellow,
      0
    ]
  ];

  List<String> _kitchenOptions = [
    'Small',
    'Medium',
    'Large',
  ];

  List<int> _selectedRooms = [];
  Map<String, dynamic> _roomQuantities = {};

  // Gender selection variables
  int? _selectedGender; // 0 for Male, 1 for Female
  List<String> _genders = ['Male', 'Female'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      body: NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.only(top: 25, right: 20.0, left: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        MouseRegion(
                          cursor: SystemMouseCursors.click,
                          onEnter: (_) => setState(() => _isHovering = true),
                          onExit: (_) => setState(() => _isHovering = false),
                          child: IconButton(
                            icon: Icon(
                              Icons.menu,
                              color: _isHovering
                                  ? Color(0xFF112D4E)
                                  : Color(0xFF112D4E),
                            ),
                            onPressed: FirebaseAuth.instance.currentUser != null
                                ? () {
                                    _scaffoldKey.currentState?.openDrawer();
                                  }
                                : null,
                          ),
                        ),
                        IconButton(
                          icon: Icon(
                            Icons.person,
                            color: Color(0xFF112D4E),
                          ),
                          onPressed: FirebaseAuth.instance.currentUser != null
                              ? () {
                                  Navigator.of(context).pop();
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => ProfileSettingsPage(
                                        isServiceProvider: true,
                                        onToggleRole: () {},
                                      ),
                                    ),
                                  );
                                }
                              : null,
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    Text(
                      ' Welcome, $_userPhoneNumber\nChoose Your Service',
                      style: TextStyle(
                        fontSize: 30,
                        color: Colors.grey.shade900,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ];
        },
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: 0),
              Expanded(
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10.0,
                    mainAxisSpacing: 10.0,
                  ),
                  itemCount: _rooms.length + 1,
                  itemBuilder: (BuildContext context, int index) {
                    if (index == _rooms.length) {
                      return kitchenWidget();
                    }
                    return roomWidget(_rooms[index], index);
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Preferred Gender of Cleaning Staff:',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: _genders.asMap().entries.map((entry) {
                        int idx = entry.key;
                        String val = entry.value;
                        String imagePath =
                            idx == 0 ? 'assets/male2.jpg' : 'assets/fmaile.jpg';
                        return Expanded(
                          child: RadioListTile(
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  imagePath,
                                  width: 32,
                                  height: 32,
                                ),
                                SizedBox(width: 2),
                                Text(val),
                              ],
                            ),
                            value: idx,
                            groupValue: _selectedGender,
                            onChanged: (int? value) {
                              setState(() {
                                _selectedGender = value;
                              });
                            },
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
              if (_selectedRooms.isNotEmpty)
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 5, horizontal: 1),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3),
                      ),
                    ],
                    borderRadius: BorderRadius.circular(50),
                    color: Colors.white,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      children: [
                        Text(
                          'Expected Cost: ${calculateTotalCost()} JD',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            shadows: [
                              Shadow(
                                color: Colors.black.withOpacity(0.5),
                                offset: Offset(0, 2),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 10),
                        ElevatedButton(
                          onPressed: () async {
                            if (_selectedGender == null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  backgroundColor: Colors.red,
                                  content: Text(
                                    'Please select the preferred gender of the cleaning staff.',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              );
                              return;
                            }

                            User? user = FirebaseAuth.instance.currentUser;
                            if (user == null) {
                              showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    title: Text('Sign In Required'),
                                    content: Text(
                                        'Please sign in to place an order.'),
                                    actions: [
                                      TextButton(
                                        child: Text('Sign In'),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    LoginPage()),
                                          );
                                        },
                                      ),
                                    ],
                                  );
                                },
                              );
                            } else {
                              // User is signed in, proceed with order
                              saveOrderToRealtimeDatabase();
                              saveOrderToFirestore();
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => AfterOrderPage(),
                                ),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xFF4C7F9A),
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(
                                horizontal: 100, vertical: 20),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(88),
                            ),
                            textStyle: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          child: Text('Order Now'),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
      drawer: Drawer(
        child: Container(
          color: Color(0xFF112D4E),
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFF112D4E),
                ),
                child: Center(
                  child: Text(
                    'Settings',
                    style: TextStyle(
                      color: Color(0xFFDBE2EF),
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.person, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Profile Settings',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProfileSettingsPage(
                        isServiceProvider: false,
                        onToggleRole: () {},
                        showAvatar: false,
                      ),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.history, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Orders History',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HistoryOrdersPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.contact_mail, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Contact Us',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ContactUsPage(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.logout, color: Color(0xFFDBE2EF)),
                title: Text(
                  'Logout',
                  style: TextStyle(color: Color(0xFFDBE2EF)),
                ),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        backgroundColor: Color(0xFF3F72AF),
                        title: Text(
                          'Confirm Logout',
                          style: TextStyle(color: Color(0xFFDBE2EF)),
                        ),
                        content: Text(
                          'Are you sure you want to log out?',
                          style: TextStyle(color: Color(0xFFDBE2EF)),
                        ),
                        actions: <Widget>[
                          TextButton(
                            child: Text(
                              'Cancel',
                              style: TextStyle(color: Color(0xFFDBE2EF)),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          TextButton(
                            child: Text(
                              'Logout',
                              style: TextStyle(color: Color(0xFFDBE2EF)),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                              handleLogout(context);
                            },
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget roomWidget(List<dynamic> room, int index) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: double.infinity, // Take full width of the grid cell
        child: AspectRatio(
          aspectRatio: 1.0, // Maintain square aspect ratio
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0),
              color: _selectedRooms.contains(index)
                  ? room[2].withOpacity(0.3)
                  : Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 2,
                  blurRadius: 5,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    setState(() {
                      if (_selectedRooms.contains(index)) {
                        _selectedRooms.remove(index);
                        if (room[0] == 'House Garden') {
                          _roomQuantities.remove('House Garden');
                          _gardenSizeNotifier.value =
                              10; // Reset garden size to default
                        } else {
                          _roomQuantities.remove(room[0]);
                        }
                      } else {
                        _selectedRooms.add(index);
                        if (room[0] == 'House Garden') {
                          _roomQuantities['House Garden'] = 1;
                          _gardenSizeNotifier.value =
                              10; // Set default garden size to 10m²
                        } else {
                          _roomQuantities[room[0]] = room[3];
                        }
                      }
                    });
                  },
                  child: Image.network(
                    room[1],
                    height: 70, // Adjust size as needed
                    width: 70, // Adjust size as needed
                  ),
                ),
                SizedBox(height: 8), // Space between image and text
                Text(
                  room[0],
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8), // Space between text and counter
                if (_selectedRooms.contains(index))
                  room[0] == 'House Garden'
                      ? ValueListenableBuilder<int>(
                          valueListenable: _gardenSizeNotifier,
                          builder: (context, gardenSize, child) {
                            return DropdownButton<int>(
                              value: gardenSize,
                              items: List.generate(
                                36,
                                (index) => DropdownMenuItem<int>(
                                  value: (index + 1) * 10,
                                  child: Text('${(index + 1) * 10} m²'),
                                ),
                              ),
                              onChanged: (int? newValue) {
                                if (newValue != null) {
                                  _gardenSizeNotifier.value = newValue;
                                  setState(() {}); // Trigger a state update
                                }
                              },
                            );
                          },
                        )
                      : Container(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                icon: Icon(Icons.remove),
                                onPressed: () {
                                  setState(() {
                                    if (_roomQuantities[room[0]] > 1) {
                                      _roomQuantities[room[0]]--;
                                    } else {
                                      _selectedRooms.remove(index);
                                      _roomQuantities.remove(room[0]);
                                    }
                                  });
                                },
                              ),
                              Text(
                                '${_roomQuantities[room[0]]}',
                                style: TextStyle(fontSize: 18),
                              ),
                              IconButton(
                                icon: Icon(Icons.add),
                                onPressed: () {
                                  setState(() {
                                    _roomQuantities[room[0]]++;
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget kitchenWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 5.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: _selectedRooms.contains(_rooms.length)
              ? Colors.purple.withOpacity(0.3)
              : Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: InkWell(
          onTap: () {
            setState(() {
              if (_selectedRooms.contains(_rooms.length)) {
                _selectedRooms.remove(_rooms.length);
                _roomQuantities.remove('Kitchen');
              } else {
                _selectedRooms.add(_rooms.length);
                _roomQuantities['Kitchen'] = 1;
              }
            });
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.network(
                'https://img.icons8.com/color/2x/kitchen-room.png',
                height: 70, // Adjusted height for better visibility
                width: 70, // Adjusted width for better visibility
              ),
              SizedBox(height: 10), // Space between image and text
              Text(
                'Kitchen',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (_selectedRooms.contains(_rooms.length))
                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: DropdownButton<String>(
                    value: _kitchenOptions[_roomQuantities['Kitchen'] - 1],
                    items: _kitchenOptions.map((String option) {
                      return DropdownMenuItem<String>(
                        value: option,
                        child: Text(option),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _roomQuantities['Kitchen'] =
                            _kitchenOptions.indexOf(newValue!) + 1;
                      });
                    },
                  ),
                )
            ],
          ),
        ),
      ),
    );
  }

  Widget sizeOfGardenInput() {
    return ValueListenableBuilder<int>(
      valueListenable: _gardenSizeNotifier,
      builder: (context, value, child) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20.0),
            Text(
              "Select the size of the garden (in m²):",
              style: const TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 10.0),
            DropdownButton<int>(
              value: _gardenSizeNotifier.value,
              items: List.generate(
                  36,
                  (index) => DropdownMenuItem<int>(
                        value: index + 10,
                        child: Text('${index + 10} m²'),
                      )),
              onChanged: (int? newValue) {
                if (newValue != null) {
                  _gardenSizeNotifier.value = newValue;
                }
              },
            ),
          ],
        );
      },
    );
  }

  double calculateTotalCost() {
    double totalCost = 0;
    for (var entry in _roomQuantities.entries) {
      switch (entry.key) {
        case 'Room':
        case 'Bedroom':
          totalCost += entry.value * 5;
          break;
        case 'Bathroom':
          totalCost += entry.value * 7;
          break;
        case 'Kitchen':
          switch (_roomQuantities['Kitchen']) {
            case 1: // Small
              totalCost += entry.value * 7;
              break;
            case 2: // Medium
              totalCost += entry.value * 10;
              break;
            case 3: // Large
              totalCost += entry.value * 15;
              break;
          }
          break;
        case 'Outdoor Stairs':
          totalCost += entry.value * 10;
          break;
        case 'House Garden':
          int gardenSize = _gardenSizeNotifier.value ?? 0;
          totalCost += entry.value * (7 + (gardenSize ~/ 10) * 5);
          break;
      }
    }
    return totalCost;
  }

  Future<void> saveOrderToDatabase() async {
    try {
      User? user = await getUser();
      if (user == null) {
        throw FirebaseAuthException(
            code: 'user-not-found', message: 'No user is currently signed in.');
      }

      String uid = user.uid;
      String phoneNumber = user.phoneNumber ?? 'Unknown'; // Placeholder

      final orderData = {
        'user_id': uid,
        'phone_number': phoneNumber,
        'selected_rooms':
            _selectedRooms.map((index) => _rooms[index][0]).toList(),
        'room_quantities': _roomQuantities,
        'preferred_gender': _selectedGender == 0 ? 'Male' : 'Female',
        'total_cost': calculateTotalCost(),
        'timestamp': DateTime.now().toIso8601String(),
      };

      await _database.child('orders').push().set(orderData);

      print('Order data saved successfully!');
    } catch (e) {
      print('Error saving order data: $e');
    }
  }

  void saveOrderToRealtimeDatabase() async {
    final databaseReference = FirebaseDatabase.instance.ref();

    try {
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String uid = user.uid; // Use UID instead of phone number

        Map<String, dynamic> orderData = {
          'user_id': uid, // Store the user UID
          'service type': _selectedRooms.map((index) {
            if (index < _rooms.length) {
              return {
                'name': _rooms[index][0],
                'quantity': _roomQuantities[_rooms[index][0]],
              };
            } else {
              return {
                'name': 'Kitchen',
                'quantity': _roomQuantities['Kitchen'],
              };
            }
          }).toList(),
          'preferredGender':
              _selectedGender != null ? _genders[_selectedGender!] : null,
          'totalCost': calculateTotalCost(),
          'timestamp': DateTime.now().toIso8601String(),
        };

        await databaseReference.child("orders").push().set(orderData);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Order saved successfully to Realtime Database!'),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('User not signed in.'),
          ),
        );
      }
    } catch (e) {
      print('Error saving order to Realtime Database: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text('Failed to save order. Please try again later.'),
        ),
      );
    }
  }

  void saveOrderToFirestore() async {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    FirebaseAuth auth = FirebaseAuth.instance;

    try {
      // Refresh the current user to ensure the latest profile information
      await auth.currentUser?.reload();
      User? user = auth.currentUser;

      if (user != null) {
        // User is signed in
        String uid = user.uid; // Get UID instead of phone number

        // Create a new document in the "orders" collection
        DocumentReference orderRef = firestore.collection('orders').doc();

        // Prepare the order data
        Map<String, dynamic> orderData = {
          'user_id': uid, // Store the user UID
          'rooms': _selectedRooms.map((index) {
            if (index < _rooms.length) {
              return {
                'name': _rooms[index][0],
                'quantity': _roomQuantities[_rooms[index][0]],
              };
            } else {
              return {
                'name': 'Kitchen',
                'quantity': _roomQuantities['Kitchen'],
              };
            }
          }).toList(),
          'preferredGender':
              _selectedGender != null ? _genders[_selectedGender!] : null,
          'totalCost': calculateTotalCost(),
          'timestamp': FieldValue.serverTimestamp(),
        };

        // Save the order data to Firestore
        await orderRef.set(orderData);

        // Show a confirmation message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Order saved successfully!'),
          ),
        );
      } else {
        // No user is signed in
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('User not signed in.'),
          ),
        );
      }
    } catch (e) {
      // Handle errors
      print('Error saving order: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save order. Please try again later.'),
        ),
      );
    }
  }

  Future<void> handleLogout(BuildContext context) async {
    try {
      // Call signOut() to log the user out
      logout();

      // After signing out, navigate to the LoginPage
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => LoginPage(),
        ),
      );
    } catch (e) {
      // Handle any errors that may occur during sign out
      print('Error signing out: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to sign out. Please try again.'),
        ),
      );
    }
  }
}
